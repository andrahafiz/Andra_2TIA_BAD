﻿namespace Project_UTS_v1
{
    partial class Form_Film
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Film));
            this.toolbar = new System.Windows.Forms.Panel();
            this.btnminimiza = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            this.kontentbangku_eg = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_eg_A8 = new System.Windows.Forms.Button();
            this.btn_eg_B7 = new System.Windows.Forms.Button();
            this.btn_eg_C7 = new System.Windows.Forms.Button();
            this.btn_eg_D7 = new System.Windows.Forms.Button();
            this.btn_eg_E7 = new System.Windows.Forms.Button();
            this.btn_eg_F7 = new System.Windows.Forms.Button();
            this.btn_eg_A7 = new System.Windows.Forms.Button();
            this.btn_eg_A9 = new System.Windows.Forms.Button();
            this.btn_eg_A6 = new System.Windows.Forms.Button();
            this.btn_eg_A5 = new System.Windows.Forms.Button();
            this.btn_eg_B8 = new System.Windows.Forms.Button();
            this.btn_eg_B9 = new System.Windows.Forms.Button();
            this.btn_eg_B6 = new System.Windows.Forms.Button();
            this.btn_eg_B5 = new System.Windows.Forms.Button();
            this.btn_eg_C8 = new System.Windows.Forms.Button();
            this.btn_eg_C9 = new System.Windows.Forms.Button();
            this.btn_eg_C6 = new System.Windows.Forms.Button();
            this.btn_eg_C5 = new System.Windows.Forms.Button();
            this.btn_eg_D8 = new System.Windows.Forms.Button();
            this.btn_eg_D9 = new System.Windows.Forms.Button();
            this.btn_eg_D6 = new System.Windows.Forms.Button();
            this.btn_eg_D5 = new System.Windows.Forms.Button();
            this.btn_eg_E8 = new System.Windows.Forms.Button();
            this.btn_eg_E9 = new System.Windows.Forms.Button();
            this.btn_eg_E6 = new System.Windows.Forms.Button();
            this.btn_eg_E5 = new System.Windows.Forms.Button();
            this.btn_eg_F8 = new System.Windows.Forms.Button();
            this.btn_eg_F9 = new System.Windows.Forms.Button();
            this.btn_eg_F6 = new System.Windows.Forms.Button();
            this.btn_eg_F5 = new System.Windows.Forms.Button();
            this.btn_eg_A4 = new System.Windows.Forms.Button();
            this.btn_eg_A3 = new System.Windows.Forms.Button();
            this.btn_eg_A2 = new System.Windows.Forms.Button();
            this.btn_eg_A1 = new System.Windows.Forms.Button();
            this.btn_eg_B4 = new System.Windows.Forms.Button();
            this.btn_eg_B3 = new System.Windows.Forms.Button();
            this.btn_eg_B2 = new System.Windows.Forms.Button();
            this.btn_eg_B1 = new System.Windows.Forms.Button();
            this.btn_eg_C4 = new System.Windows.Forms.Button();
            this.btn_eg_C3 = new System.Windows.Forms.Button();
            this.btn_eg_C2 = new System.Windows.Forms.Button();
            this.btn_eg_C1 = new System.Windows.Forms.Button();
            this.btn_eg_D4 = new System.Windows.Forms.Button();
            this.btn_eg_D3 = new System.Windows.Forms.Button();
            this.btn_eg_D2 = new System.Windows.Forms.Button();
            this.btn_eg_D1 = new System.Windows.Forms.Button();
            this.btn_eg_E4 = new System.Windows.Forms.Button();
            this.btn_eg_E3 = new System.Windows.Forms.Button();
            this.btn_eg_E2 = new System.Windows.Forms.Button();
            this.btn_eg_E1 = new System.Windows.Forms.Button();
            this.btn_eg_F4 = new System.Windows.Forms.Button();
            this.btn_eg_F3 = new System.Windows.Forms.Button();
            this.btn_eg_F2 = new System.Windows.Forms.Button();
            this.btn_eg_F1 = new System.Windows.Forms.Button();
            this.kontentbangku_bp = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_bp_A8 = new System.Windows.Forms.Button();
            this.btn_bp_B7 = new System.Windows.Forms.Button();
            this.btn_bp_C7 = new System.Windows.Forms.Button();
            this.btn_bp_D7 = new System.Windows.Forms.Button();
            this.btn_bp_E7 = new System.Windows.Forms.Button();
            this.btn_bp_F7 = new System.Windows.Forms.Button();
            this.btn_bp_A7 = new System.Windows.Forms.Button();
            this.btn_bp_A9 = new System.Windows.Forms.Button();
            this.btn_bp_A6 = new System.Windows.Forms.Button();
            this.btn_bp_A5 = new System.Windows.Forms.Button();
            this.btn_bp_B8 = new System.Windows.Forms.Button();
            this.btn_bp_B9 = new System.Windows.Forms.Button();
            this.btn_bp_B6 = new System.Windows.Forms.Button();
            this.btn_bp_B5 = new System.Windows.Forms.Button();
            this.btn_bp_C8 = new System.Windows.Forms.Button();
            this.btn_bp_C9 = new System.Windows.Forms.Button();
            this.btn_bp_C6 = new System.Windows.Forms.Button();
            this.btn_bp_C5 = new System.Windows.Forms.Button();
            this.btn_bp_D8 = new System.Windows.Forms.Button();
            this.btn_bp_D9 = new System.Windows.Forms.Button();
            this.btn_bp_D6 = new System.Windows.Forms.Button();
            this.btn_bp_D5 = new System.Windows.Forms.Button();
            this.btn_bp_E8 = new System.Windows.Forms.Button();
            this.btn_bp_E9 = new System.Windows.Forms.Button();
            this.btn_bp_E6 = new System.Windows.Forms.Button();
            this.btn_bp_E5 = new System.Windows.Forms.Button();
            this.btn_bp_F8 = new System.Windows.Forms.Button();
            this.btn_bp_F9 = new System.Windows.Forms.Button();
            this.btn_bp_F6 = new System.Windows.Forms.Button();
            this.btn_bp_F5 = new System.Windows.Forms.Button();
            this.btn_bp_A4 = new System.Windows.Forms.Button();
            this.btn_bp_A3 = new System.Windows.Forms.Button();
            this.btn_bp_A2 = new System.Windows.Forms.Button();
            this.btn_bp_A1 = new System.Windows.Forms.Button();
            this.btn_bp_B4 = new System.Windows.Forms.Button();
            this.btn_bp_B3 = new System.Windows.Forms.Button();
            this.btn_bp_B2 = new System.Windows.Forms.Button();
            this.btn_bp_B1 = new System.Windows.Forms.Button();
            this.btn_bp_C4 = new System.Windows.Forms.Button();
            this.btn_bp_C3 = new System.Windows.Forms.Button();
            this.btn_bp_C2 = new System.Windows.Forms.Button();
            this.btn_bp_C1 = new System.Windows.Forms.Button();
            this.btn_bp_D4 = new System.Windows.Forms.Button();
            this.btn_bp_D3 = new System.Windows.Forms.Button();
            this.btn_bp_D2 = new System.Windows.Forms.Button();
            this.btn_bp_D1 = new System.Windows.Forms.Button();
            this.btn_bp_E4 = new System.Windows.Forms.Button();
            this.btn_bp_E3 = new System.Windows.Forms.Button();
            this.btn_bp_E2 = new System.Windows.Forms.Button();
            this.btn_bp_E1 = new System.Windows.Forms.Button();
            this.btn_bp_F4 = new System.Windows.Forms.Button();
            this.btn_bp_F3 = new System.Windows.Forms.Button();
            this.btn_bp_F2 = new System.Windows.Forms.Button();
            this.btn_bp_F1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.kontentbangku_ff = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_ff_A8 = new System.Windows.Forms.Button();
            this.btn_ff_B7 = new System.Windows.Forms.Button();
            this.btn_ff_C7 = new System.Windows.Forms.Button();
            this.btn_ff_D7 = new System.Windows.Forms.Button();
            this.btn_ff_E7 = new System.Windows.Forms.Button();
            this.btn_ff_F7 = new System.Windows.Forms.Button();
            this.btn_ff_A7 = new System.Windows.Forms.Button();
            this.btn_ff_A9 = new System.Windows.Forms.Button();
            this.btn_ff_A6 = new System.Windows.Forms.Button();
            this.btn_ff_A5 = new System.Windows.Forms.Button();
            this.btn_ff_B8 = new System.Windows.Forms.Button();
            this.btn_ff_B9 = new System.Windows.Forms.Button();
            this.btn_ff_B6 = new System.Windows.Forms.Button();
            this.btn_ff_B5 = new System.Windows.Forms.Button();
            this.btn_ff_C8 = new System.Windows.Forms.Button();
            this.btn_ff_C9 = new System.Windows.Forms.Button();
            this.btn_ff_C6 = new System.Windows.Forms.Button();
            this.btn_ff_C5 = new System.Windows.Forms.Button();
            this.btn_ff_D8 = new System.Windows.Forms.Button();
            this.btn_ff_D9 = new System.Windows.Forms.Button();
            this.btn_ff_D6 = new System.Windows.Forms.Button();
            this.btn_ff_D5 = new System.Windows.Forms.Button();
            this.btn_ff_E8 = new System.Windows.Forms.Button();
            this.btn_ff_E9 = new System.Windows.Forms.Button();
            this.btn_ff_E6 = new System.Windows.Forms.Button();
            this.btn_ff_E5 = new System.Windows.Forms.Button();
            this.btn_ff_F8 = new System.Windows.Forms.Button();
            this.btn_ff_F9 = new System.Windows.Forms.Button();
            this.btn_ff_F6 = new System.Windows.Forms.Button();
            this.btn_ff_F5 = new System.Windows.Forms.Button();
            this.btn_ff_A4 = new System.Windows.Forms.Button();
            this.btn_ff_A3 = new System.Windows.Forms.Button();
            this.btn_ff_A2 = new System.Windows.Forms.Button();
            this.btn_ff_A1 = new System.Windows.Forms.Button();
            this.btn_ff_B4 = new System.Windows.Forms.Button();
            this.btn_ff_B3 = new System.Windows.Forms.Button();
            this.btn_ff_B2 = new System.Windows.Forms.Button();
            this.btn_ff_B1 = new System.Windows.Forms.Button();
            this.btn_ff_C4 = new System.Windows.Forms.Button();
            this.btn_ff_C3 = new System.Windows.Forms.Button();
            this.btn_ff_C2 = new System.Windows.Forms.Button();
            this.btn_ff_C1 = new System.Windows.Forms.Button();
            this.btn_ff_D4 = new System.Windows.Forms.Button();
            this.btn_ff_D3 = new System.Windows.Forms.Button();
            this.btn_ff_D2 = new System.Windows.Forms.Button();
            this.btn_ff_D1 = new System.Windows.Forms.Button();
            this.btn_ff_E4 = new System.Windows.Forms.Button();
            this.btn_ff_E3 = new System.Windows.Forms.Button();
            this.btn_ff_E2 = new System.Windows.Forms.Button();
            this.btn_ff_E1 = new System.Windows.Forms.Button();
            this.btn_ff_F4 = new System.Windows.Forms.Button();
            this.btn_ff_F3 = new System.Windows.Forms.Button();
            this.btn_ff_F2 = new System.Windows.Forms.Button();
            this.btn_ff_F1 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.my_timer = new System.Windows.Forms.Timer(this.components);
            this.menu = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnbangku = new System.Windows.Forms.Button();
            this.btnfilm = new System.Windows.Forms.Button();
            this.kontentfilm = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cb_jmlorang = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbPengunjung = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btnFF = new System.Windows.Forms.Button();
            this.btnBP = new System.Windows.Forms.Button();
            this.btnEG = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.toolbar.SuspendLayout();
            this.kontentbangku_eg.SuspendLayout();
            this.panel6.SuspendLayout();
            this.kontentbangku_bp.SuspendLayout();
            this.panel7.SuspendLayout();
            this.kontentbangku_ff.SuspendLayout();
            this.panel8.SuspendLayout();
            this.menu.SuspendLayout();
            this.kontentfilm.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // toolbar
            // 
            this.toolbar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(168)))), ((int)(((byte)(120)))));
            this.toolbar.Controls.Add(this.btnminimiza);
            this.toolbar.Controls.Add(this.btnclose);
            this.toolbar.Dock = System.Windows.Forms.DockStyle.Top;
            this.toolbar.Location = new System.Drawing.Point(370, 0);
            this.toolbar.Name = "toolbar";
            this.toolbar.Size = new System.Drawing.Size(830, 38);
            this.toolbar.TabIndex = 2;
            // 
            // btnminimiza
            // 
            this.btnminimiza.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnminimiza.FlatAppearance.BorderSize = 0;
            this.btnminimiza.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnminimiza.Image = ((System.Drawing.Image)(resources.GetObject("btnminimiza.Image")));
            this.btnminimiza.Location = new System.Drawing.Point(771, 7);
            this.btnminimiza.Margin = new System.Windows.Forms.Padding(0);
            this.btnminimiza.Name = "btnminimiza";
            this.btnminimiza.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.btnminimiza.Size = new System.Drawing.Size(25, 25);
            this.btnminimiza.TabIndex = 4;
            this.btnminimiza.UseVisualStyleBackColor = true;
            this.btnminimiza.Click += new System.EventHandler(this.btnminimiza_Click);
            // 
            // btnclose
            // 
            this.btnclose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnclose.FlatAppearance.BorderSize = 0;
            this.btnclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclose.Image = ((System.Drawing.Image)(resources.GetObject("btnclose.Image")));
            this.btnclose.Location = new System.Drawing.Point(796, 7);
            this.btnclose.Margin = new System.Windows.Forms.Padding(0);
            this.btnclose.Name = "btnclose";
            this.btnclose.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.btnclose.Size = new System.Drawing.Size(25, 25);
            this.btnclose.TabIndex = 0;
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // kontentbangku_eg
            // 
            this.kontentbangku_eg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(168)))), ((int)(((byte)(120)))));
            this.kontentbangku_eg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.kontentbangku_eg.Controls.Add(this.button2);
            this.kontentbangku_eg.Controls.Add(this.button3);
            this.kontentbangku_eg.Controls.Add(this.label2);
            this.kontentbangku_eg.Controls.Add(this.panel5);
            this.kontentbangku_eg.Controls.Add(this.panel6);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_A8);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_B7);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_C7);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_D7);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_E7);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_F7);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_A7);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_A9);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_A6);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_A5);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_B8);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_B9);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_B6);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_B5);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_C8);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_C9);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_C6);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_C5);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_D8);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_D9);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_D6);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_D5);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_E8);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_E9);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_E6);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_E5);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_F8);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_F9);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_F6);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_F5);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_A4);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_A3);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_A2);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_A1);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_B4);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_B3);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_B2);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_B1);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_C4);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_C3);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_C2);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_C1);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_D4);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_D3);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_D2);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_D1);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_E4);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_E3);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_E2);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_E1);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_F4);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_F3);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_F2);
            this.kontentbangku_eg.Controls.Add(this.btn_eg_F1);
            this.kontentbangku_eg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kontentbangku_eg.Location = new System.Drawing.Point(370, 38);
            this.kontentbangku_eg.Name = "kontentbangku_eg";
            this.kontentbangku_eg.Size = new System.Drawing.Size(830, 705);
            this.kontentbangku_eg.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(41)))), ((int)(((byte)(5)))));
            this.button2.Enabled = false;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(317, 627);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(182, 54);
            this.button2.TabIndex = 72;
            this.button2.Text = "Bayar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.bayar);
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(72)))), ((int)(((byte)(24)))));
            this.button3.Image = global::Project_UTS_v1.Properties.Resources.back;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(53, 20);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(110, 56);
            this.button3.TabIndex = 68;
            this.button3.Text = "Back";
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.backtofilm);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(72)))), ((int)(((byte)(24)))));
            this.label2.Location = new System.Drawing.Point(272, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(268, 56);
            this.label2.TabIndex = 9;
            this.label2.Text = "End Game";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(72)))), ((int)(((byte)(24)))));
            this.panel5.Location = new System.Drawing.Point(359, 76);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(115, 10);
            this.panel5.TabIndex = 8;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(41)))), ((int)(((byte)(5)))));
            this.panel6.Controls.Add(this.label3);
            this.panel6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.panel6.Location = new System.Drawing.Point(53, 126);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(711, 35);
            this.panel6.TabIndex = 60;
            this.panel6.Click += new System.EventHandler(this.panel6_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(313, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "Layar";
            // 
            // btn_eg_A8
            // 
            this.btn_eg_A8.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_A8.FlatAppearance.BorderSize = 0;
            this.btn_eg_A8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_A8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_A8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_A8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_A8.Location = new System.Drawing.Point(638, 547);
            this.btn_eg_A8.Name = "btn_eg_A8";
            this.btn_eg_A8.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_A8.TabIndex = 66;
            this.btn_eg_A8.Text = "A8";
            this.btn_eg_A8.UseVisualStyleBackColor = false;
            this.btn_eg_A8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_B7
            // 
            this.btn_eg_B7.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_B7.FlatAppearance.BorderSize = 0;
            this.btn_eg_B7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_B7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_B7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_B7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_B7.Location = new System.Drawing.Point(507, 481);
            this.btn_eg_B7.Name = "btn_eg_B7";
            this.btn_eg_B7.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_B7.TabIndex = 65;
            this.btn_eg_B7.Text = "B7";
            this.btn_eg_B7.UseVisualStyleBackColor = false;
            this.btn_eg_B7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_C7
            // 
            this.btn_eg_C7.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_C7.FlatAppearance.BorderSize = 0;
            this.btn_eg_C7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_C7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_C7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_C7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_C7.Location = new System.Drawing.Point(507, 415);
            this.btn_eg_C7.Name = "btn_eg_C7";
            this.btn_eg_C7.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_C7.TabIndex = 64;
            this.btn_eg_C7.Text = "C7";
            this.btn_eg_C7.UseVisualStyleBackColor = false;
            this.btn_eg_C7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_D7
            // 
            this.btn_eg_D7.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_D7.FlatAppearance.BorderSize = 0;
            this.btn_eg_D7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_D7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_D7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_D7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_D7.Location = new System.Drawing.Point(507, 349);
            this.btn_eg_D7.Name = "btn_eg_D7";
            this.btn_eg_D7.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_D7.TabIndex = 63;
            this.btn_eg_D7.Text = "D7";
            this.btn_eg_D7.UseVisualStyleBackColor = false;
            this.btn_eg_D7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_E7
            // 
            this.btn_eg_E7.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_E7.FlatAppearance.BorderSize = 0;
            this.btn_eg_E7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_E7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_E7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_E7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_E7.Location = new System.Drawing.Point(507, 283);
            this.btn_eg_E7.Name = "btn_eg_E7";
            this.btn_eg_E7.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_E7.TabIndex = 62;
            this.btn_eg_E7.Text = "E7";
            this.btn_eg_E7.UseVisualStyleBackColor = false;
            this.btn_eg_E7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_F7
            // 
            this.btn_eg_F7.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_F7.FlatAppearance.BorderSize = 0;
            this.btn_eg_F7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_F7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_F7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_F7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_F7.Location = new System.Drawing.Point(507, 217);
            this.btn_eg_F7.Name = "btn_eg_F7";
            this.btn_eg_F7.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_F7.TabIndex = 61;
            this.btn_eg_F7.Text = "F7";
            this.btn_eg_F7.UseVisualStyleBackColor = false;
            this.btn_eg_F7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_A7
            // 
            this.btn_eg_A7.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_A7.FlatAppearance.BorderSize = 0;
            this.btn_eg_A7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_A7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_A7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_A7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_A7.Location = new System.Drawing.Point(507, 547);
            this.btn_eg_A7.Name = "btn_eg_A7";
            this.btn_eg_A7.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_A7.TabIndex = 59;
            this.btn_eg_A7.Text = "A7";
            this.btn_eg_A7.UseVisualStyleBackColor = false;
            this.btn_eg_A7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_A9
            // 
            this.btn_eg_A9.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_A9.FlatAppearance.BorderSize = 0;
            this.btn_eg_A9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_A9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_A9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_A9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_A9.Location = new System.Drawing.Point(704, 547);
            this.btn_eg_A9.Name = "btn_eg_A9";
            this.btn_eg_A9.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_A9.TabIndex = 57;
            this.btn_eg_A9.Text = "A9";
            this.btn_eg_A9.UseVisualStyleBackColor = false;
            this.btn_eg_A9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_A6
            // 
            this.btn_eg_A6.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_A6.FlatAppearance.BorderSize = 0;
            this.btn_eg_A6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_A6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_A6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_A6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_A6.Location = new System.Drawing.Point(437, 547);
            this.btn_eg_A6.Name = "btn_eg_A6";
            this.btn_eg_A6.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_A6.TabIndex = 55;
            this.btn_eg_A6.Text = "A6";
            this.btn_eg_A6.UseVisualStyleBackColor = false;
            this.btn_eg_A6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_A5
            // 
            this.btn_eg_A5.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_A5.FlatAppearance.BorderSize = 0;
            this.btn_eg_A5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_A5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_A5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_A5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_A5.Location = new System.Drawing.Point(371, 547);
            this.btn_eg_A5.Name = "btn_eg_A5";
            this.btn_eg_A5.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_A5.TabIndex = 54;
            this.btn_eg_A5.Text = "A5";
            this.btn_eg_A5.UseVisualStyleBackColor = false;
            this.btn_eg_A5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_B8
            // 
            this.btn_eg_B8.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_B8.FlatAppearance.BorderSize = 0;
            this.btn_eg_B8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_B8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_B8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_B8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_B8.Location = new System.Drawing.Point(638, 481);
            this.btn_eg_B8.Name = "btn_eg_B8";
            this.btn_eg_B8.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_B8.TabIndex = 53;
            this.btn_eg_B8.Text = "B8";
            this.btn_eg_B8.UseVisualStyleBackColor = false;
            this.btn_eg_B8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_B9
            // 
            this.btn_eg_B9.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_B9.FlatAppearance.BorderSize = 0;
            this.btn_eg_B9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_B9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_B9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_B9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_B9.Location = new System.Drawing.Point(704, 481);
            this.btn_eg_B9.Name = "btn_eg_B9";
            this.btn_eg_B9.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_B9.TabIndex = 52;
            this.btn_eg_B9.Text = "B9";
            this.btn_eg_B9.UseVisualStyleBackColor = false;
            this.btn_eg_B9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_B6
            // 
            this.btn_eg_B6.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_B6.FlatAppearance.BorderSize = 0;
            this.btn_eg_B6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_B6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_B6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_B6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_B6.Location = new System.Drawing.Point(437, 481);
            this.btn_eg_B6.Name = "btn_eg_B6";
            this.btn_eg_B6.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_B6.TabIndex = 51;
            this.btn_eg_B6.Text = "B6";
            this.btn_eg_B6.UseVisualStyleBackColor = false;
            this.btn_eg_B6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_B5
            // 
            this.btn_eg_B5.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_B5.FlatAppearance.BorderSize = 0;
            this.btn_eg_B5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_B5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_B5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_B5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_B5.Location = new System.Drawing.Point(371, 481);
            this.btn_eg_B5.Name = "btn_eg_B5";
            this.btn_eg_B5.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_B5.TabIndex = 50;
            this.btn_eg_B5.Text = "B5";
            this.btn_eg_B5.UseVisualStyleBackColor = false;
            this.btn_eg_B5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_C8
            // 
            this.btn_eg_C8.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_C8.FlatAppearance.BorderSize = 0;
            this.btn_eg_C8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_C8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_C8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_C8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_C8.Location = new System.Drawing.Point(638, 415);
            this.btn_eg_C8.Name = "btn_eg_C8";
            this.btn_eg_C8.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_C8.TabIndex = 49;
            this.btn_eg_C8.Text = "C8";
            this.btn_eg_C8.UseVisualStyleBackColor = false;
            this.btn_eg_C8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_C9
            // 
            this.btn_eg_C9.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_C9.FlatAppearance.BorderSize = 0;
            this.btn_eg_C9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_C9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_C9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_C9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_C9.Location = new System.Drawing.Point(704, 415);
            this.btn_eg_C9.Name = "btn_eg_C9";
            this.btn_eg_C9.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_C9.TabIndex = 48;
            this.btn_eg_C9.Text = "C9";
            this.btn_eg_C9.UseVisualStyleBackColor = false;
            this.btn_eg_C9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_C6
            // 
            this.btn_eg_C6.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_C6.FlatAppearance.BorderSize = 0;
            this.btn_eg_C6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_C6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_C6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_C6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_C6.Location = new System.Drawing.Point(437, 415);
            this.btn_eg_C6.Name = "btn_eg_C6";
            this.btn_eg_C6.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_C6.TabIndex = 47;
            this.btn_eg_C6.Text = "C6";
            this.btn_eg_C6.UseVisualStyleBackColor = false;
            this.btn_eg_C6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_C5
            // 
            this.btn_eg_C5.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_C5.FlatAppearance.BorderSize = 0;
            this.btn_eg_C5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_C5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_C5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_C5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_C5.Location = new System.Drawing.Point(371, 415);
            this.btn_eg_C5.Name = "btn_eg_C5";
            this.btn_eg_C5.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_C5.TabIndex = 46;
            this.btn_eg_C5.Text = "C5";
            this.btn_eg_C5.UseVisualStyleBackColor = false;
            this.btn_eg_C5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_D8
            // 
            this.btn_eg_D8.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_D8.FlatAppearance.BorderSize = 0;
            this.btn_eg_D8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_D8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_D8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_D8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_D8.Location = new System.Drawing.Point(638, 349);
            this.btn_eg_D8.Name = "btn_eg_D8";
            this.btn_eg_D8.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_D8.TabIndex = 45;
            this.btn_eg_D8.Text = "D8";
            this.btn_eg_D8.UseVisualStyleBackColor = false;
            this.btn_eg_D8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_D9
            // 
            this.btn_eg_D9.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_D9.FlatAppearance.BorderSize = 0;
            this.btn_eg_D9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_D9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_D9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_D9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_D9.Location = new System.Drawing.Point(704, 349);
            this.btn_eg_D9.Name = "btn_eg_D9";
            this.btn_eg_D9.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_D9.TabIndex = 44;
            this.btn_eg_D9.Text = "D9";
            this.btn_eg_D9.UseVisualStyleBackColor = false;
            this.btn_eg_D9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_D6
            // 
            this.btn_eg_D6.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_D6.FlatAppearance.BorderSize = 0;
            this.btn_eg_D6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_D6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_D6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_D6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_D6.Location = new System.Drawing.Point(437, 349);
            this.btn_eg_D6.Name = "btn_eg_D6";
            this.btn_eg_D6.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_D6.TabIndex = 43;
            this.btn_eg_D6.Text = "D6";
            this.btn_eg_D6.UseVisualStyleBackColor = false;
            this.btn_eg_D6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_D5
            // 
            this.btn_eg_D5.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_D5.FlatAppearance.BorderSize = 0;
            this.btn_eg_D5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_D5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_D5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_D5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_D5.Location = new System.Drawing.Point(371, 349);
            this.btn_eg_D5.Name = "btn_eg_D5";
            this.btn_eg_D5.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_D5.TabIndex = 42;
            this.btn_eg_D5.Text = "D5";
            this.btn_eg_D5.UseVisualStyleBackColor = false;
            this.btn_eg_D5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_E8
            // 
            this.btn_eg_E8.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_E8.FlatAppearance.BorderSize = 0;
            this.btn_eg_E8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_E8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_E8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_E8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_E8.Location = new System.Drawing.Point(638, 283);
            this.btn_eg_E8.Name = "btn_eg_E8";
            this.btn_eg_E8.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_E8.TabIndex = 41;
            this.btn_eg_E8.Text = "E8";
            this.btn_eg_E8.UseVisualStyleBackColor = false;
            this.btn_eg_E8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_E9
            // 
            this.btn_eg_E9.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_E9.FlatAppearance.BorderSize = 0;
            this.btn_eg_E9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_E9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_E9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_E9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_E9.Location = new System.Drawing.Point(704, 283);
            this.btn_eg_E9.Name = "btn_eg_E9";
            this.btn_eg_E9.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_E9.TabIndex = 40;
            this.btn_eg_E9.Text = "E9";
            this.btn_eg_E9.UseVisualStyleBackColor = false;
            this.btn_eg_E9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_E6
            // 
            this.btn_eg_E6.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_E6.FlatAppearance.BorderSize = 0;
            this.btn_eg_E6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_E6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_E6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_E6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_E6.Location = new System.Drawing.Point(437, 283);
            this.btn_eg_E6.Name = "btn_eg_E6";
            this.btn_eg_E6.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_E6.TabIndex = 39;
            this.btn_eg_E6.Text = "E6";
            this.btn_eg_E6.UseVisualStyleBackColor = false;
            this.btn_eg_E6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_E5
            // 
            this.btn_eg_E5.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_E5.FlatAppearance.BorderSize = 0;
            this.btn_eg_E5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_E5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_E5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_E5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_E5.Location = new System.Drawing.Point(371, 283);
            this.btn_eg_E5.Name = "btn_eg_E5";
            this.btn_eg_E5.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_E5.TabIndex = 38;
            this.btn_eg_E5.Text = "E5";
            this.btn_eg_E5.UseVisualStyleBackColor = false;
            this.btn_eg_E5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_F8
            // 
            this.btn_eg_F8.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_F8.FlatAppearance.BorderSize = 0;
            this.btn_eg_F8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_F8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_F8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_F8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_F8.Location = new System.Drawing.Point(638, 217);
            this.btn_eg_F8.Name = "btn_eg_F8";
            this.btn_eg_F8.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_F8.TabIndex = 37;
            this.btn_eg_F8.Text = "F8";
            this.btn_eg_F8.UseVisualStyleBackColor = false;
            this.btn_eg_F8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_F9
            // 
            this.btn_eg_F9.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_F9.FlatAppearance.BorderSize = 0;
            this.btn_eg_F9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_F9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_F9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_F9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_F9.Location = new System.Drawing.Point(704, 217);
            this.btn_eg_F9.Name = "btn_eg_F9";
            this.btn_eg_F9.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_F9.TabIndex = 36;
            this.btn_eg_F9.Text = "F9";
            this.btn_eg_F9.UseVisualStyleBackColor = false;
            this.btn_eg_F9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_F6
            // 
            this.btn_eg_F6.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_F6.FlatAppearance.BorderSize = 0;
            this.btn_eg_F6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_F6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_F6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_F6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_F6.Location = new System.Drawing.Point(437, 217);
            this.btn_eg_F6.Name = "btn_eg_F6";
            this.btn_eg_F6.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_F6.TabIndex = 35;
            this.btn_eg_F6.Text = "F6";
            this.btn_eg_F6.UseVisualStyleBackColor = false;
            this.btn_eg_F6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_F5
            // 
            this.btn_eg_F5.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_F5.FlatAppearance.BorderSize = 0;
            this.btn_eg_F5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_F5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_F5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_F5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_F5.Location = new System.Drawing.Point(371, 217);
            this.btn_eg_F5.Name = "btn_eg_F5";
            this.btn_eg_F5.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_F5.TabIndex = 34;
            this.btn_eg_F5.Text = "F5";
            this.btn_eg_F5.UseVisualStyleBackColor = false;
            this.btn_eg_F5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_A4
            // 
            this.btn_eg_A4.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_A4.FlatAppearance.BorderSize = 0;
            this.btn_eg_A4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_A4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_A4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_A4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_A4.Location = new System.Drawing.Point(247, 547);
            this.btn_eg_A4.Name = "btn_eg_A4";
            this.btn_eg_A4.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_A4.TabIndex = 33;
            this.btn_eg_A4.Text = "A4";
            this.btn_eg_A4.UseVisualStyleBackColor = false;
            this.btn_eg_A4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_A3
            // 
            this.btn_eg_A3.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_A3.FlatAppearance.BorderSize = 0;
            this.btn_eg_A3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_A3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_A3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_A3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_A3.Location = new System.Drawing.Point(181, 547);
            this.btn_eg_A3.Name = "btn_eg_A3";
            this.btn_eg_A3.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_A3.TabIndex = 32;
            this.btn_eg_A3.Text = "A3";
            this.btn_eg_A3.UseVisualStyleBackColor = false;
            this.btn_eg_A3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_A2
            // 
            this.btn_eg_A2.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_A2.FlatAppearance.BorderSize = 0;
            this.btn_eg_A2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_A2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_A2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_A2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_A2.Location = new System.Drawing.Point(119, 547);
            this.btn_eg_A2.Name = "btn_eg_A2";
            this.btn_eg_A2.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_A2.TabIndex = 31;
            this.btn_eg_A2.Text = "A2";
            this.btn_eg_A2.UseVisualStyleBackColor = false;
            this.btn_eg_A2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_A1
            // 
            this.btn_eg_A1.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_A1.FlatAppearance.BorderSize = 0;
            this.btn_eg_A1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_A1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_A1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_A1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_A1.Location = new System.Drawing.Point(53, 547);
            this.btn_eg_A1.Name = "btn_eg_A1";
            this.btn_eg_A1.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_A1.TabIndex = 30;
            this.btn_eg_A1.Text = "A1";
            this.btn_eg_A1.UseVisualStyleBackColor = false;
            this.btn_eg_A1.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_B4
            // 
            this.btn_eg_B4.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_B4.FlatAppearance.BorderSize = 0;
            this.btn_eg_B4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_B4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_B4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_B4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_B4.Location = new System.Drawing.Point(247, 481);
            this.btn_eg_B4.Name = "btn_eg_B4";
            this.btn_eg_B4.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_B4.TabIndex = 29;
            this.btn_eg_B4.Text = "B4";
            this.btn_eg_B4.UseVisualStyleBackColor = false;
            this.btn_eg_B4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_B3
            // 
            this.btn_eg_B3.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_B3.FlatAppearance.BorderSize = 0;
            this.btn_eg_B3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_B3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_B3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_B3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_B3.Location = new System.Drawing.Point(181, 481);
            this.btn_eg_B3.Name = "btn_eg_B3";
            this.btn_eg_B3.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_B3.TabIndex = 28;
            this.btn_eg_B3.Text = "B3";
            this.btn_eg_B3.UseVisualStyleBackColor = false;
            this.btn_eg_B3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_B2
            // 
            this.btn_eg_B2.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_B2.FlatAppearance.BorderSize = 0;
            this.btn_eg_B2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_B2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_B2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_B2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_B2.Location = new System.Drawing.Point(119, 481);
            this.btn_eg_B2.Name = "btn_eg_B2";
            this.btn_eg_B2.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_B2.TabIndex = 27;
            this.btn_eg_B2.Text = "B2";
            this.btn_eg_B2.UseVisualStyleBackColor = false;
            this.btn_eg_B2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_B1
            // 
            this.btn_eg_B1.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_B1.FlatAppearance.BorderSize = 0;
            this.btn_eg_B1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_B1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_B1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_B1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_B1.Location = new System.Drawing.Point(53, 481);
            this.btn_eg_B1.Name = "btn_eg_B1";
            this.btn_eg_B1.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_B1.TabIndex = 26;
            this.btn_eg_B1.Text = "B1";
            this.btn_eg_B1.UseVisualStyleBackColor = false;
            this.btn_eg_B1.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_C4
            // 
            this.btn_eg_C4.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_C4.FlatAppearance.BorderSize = 0;
            this.btn_eg_C4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_C4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_C4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_C4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_C4.Location = new System.Drawing.Point(247, 415);
            this.btn_eg_C4.Name = "btn_eg_C4";
            this.btn_eg_C4.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_C4.TabIndex = 25;
            this.btn_eg_C4.Text = "C4";
            this.btn_eg_C4.UseVisualStyleBackColor = false;
            this.btn_eg_C4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_C3
            // 
            this.btn_eg_C3.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_C3.FlatAppearance.BorderSize = 0;
            this.btn_eg_C3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_C3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_C3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_C3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_C3.Location = new System.Drawing.Point(181, 415);
            this.btn_eg_C3.Name = "btn_eg_C3";
            this.btn_eg_C3.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_C3.TabIndex = 24;
            this.btn_eg_C3.Text = "C3";
            this.btn_eg_C3.UseVisualStyleBackColor = false;
            this.btn_eg_C3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_C2
            // 
            this.btn_eg_C2.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_C2.FlatAppearance.BorderSize = 0;
            this.btn_eg_C2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_C2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_C2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_C2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_C2.Location = new System.Drawing.Point(119, 415);
            this.btn_eg_C2.Name = "btn_eg_C2";
            this.btn_eg_C2.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_C2.TabIndex = 23;
            this.btn_eg_C2.Text = "C2";
            this.btn_eg_C2.UseVisualStyleBackColor = false;
            this.btn_eg_C2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_C1
            // 
            this.btn_eg_C1.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_C1.FlatAppearance.BorderSize = 0;
            this.btn_eg_C1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_C1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_C1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_C1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_C1.Location = new System.Drawing.Point(53, 415);
            this.btn_eg_C1.Name = "btn_eg_C1";
            this.btn_eg_C1.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_C1.TabIndex = 22;
            this.btn_eg_C1.Text = "C1";
            this.btn_eg_C1.UseVisualStyleBackColor = false;
            this.btn_eg_C1.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_D4
            // 
            this.btn_eg_D4.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_D4.FlatAppearance.BorderSize = 0;
            this.btn_eg_D4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_D4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_D4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_D4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_D4.Location = new System.Drawing.Point(247, 349);
            this.btn_eg_D4.Name = "btn_eg_D4";
            this.btn_eg_D4.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_D4.TabIndex = 21;
            this.btn_eg_D4.Text = "D4";
            this.btn_eg_D4.UseVisualStyleBackColor = false;
            this.btn_eg_D4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_D3
            // 
            this.btn_eg_D3.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_D3.FlatAppearance.BorderSize = 0;
            this.btn_eg_D3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_D3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_D3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_D3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_D3.Location = new System.Drawing.Point(181, 349);
            this.btn_eg_D3.Name = "btn_eg_D3";
            this.btn_eg_D3.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_D3.TabIndex = 20;
            this.btn_eg_D3.Text = "D3";
            this.btn_eg_D3.UseVisualStyleBackColor = false;
            this.btn_eg_D3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_D2
            // 
            this.btn_eg_D2.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_D2.FlatAppearance.BorderSize = 0;
            this.btn_eg_D2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_D2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_D2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_D2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_D2.Location = new System.Drawing.Point(119, 349);
            this.btn_eg_D2.Name = "btn_eg_D2";
            this.btn_eg_D2.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_D2.TabIndex = 19;
            this.btn_eg_D2.Text = "D2";
            this.btn_eg_D2.UseVisualStyleBackColor = false;
            this.btn_eg_D2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_D1
            // 
            this.btn_eg_D1.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_D1.FlatAppearance.BorderSize = 0;
            this.btn_eg_D1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_D1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_D1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_D1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_D1.Location = new System.Drawing.Point(53, 349);
            this.btn_eg_D1.Name = "btn_eg_D1";
            this.btn_eg_D1.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_D1.TabIndex = 18;
            this.btn_eg_D1.Text = "D1";
            this.btn_eg_D1.UseVisualStyleBackColor = false;
            this.btn_eg_D1.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_E4
            // 
            this.btn_eg_E4.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_E4.FlatAppearance.BorderSize = 0;
            this.btn_eg_E4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_E4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_E4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_E4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_E4.Location = new System.Drawing.Point(247, 283);
            this.btn_eg_E4.Name = "btn_eg_E4";
            this.btn_eg_E4.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_E4.TabIndex = 17;
            this.btn_eg_E4.Text = "E4";
            this.btn_eg_E4.UseVisualStyleBackColor = false;
            this.btn_eg_E4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_E3
            // 
            this.btn_eg_E3.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_E3.FlatAppearance.BorderSize = 0;
            this.btn_eg_E3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_E3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_E3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_E3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_E3.Location = new System.Drawing.Point(181, 283);
            this.btn_eg_E3.Name = "btn_eg_E3";
            this.btn_eg_E3.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_E3.TabIndex = 16;
            this.btn_eg_E3.Text = "E3";
            this.btn_eg_E3.UseVisualStyleBackColor = false;
            this.btn_eg_E3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_E2
            // 
            this.btn_eg_E2.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_E2.FlatAppearance.BorderSize = 0;
            this.btn_eg_E2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_E2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_E2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_E2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_E2.Location = new System.Drawing.Point(119, 283);
            this.btn_eg_E2.Name = "btn_eg_E2";
            this.btn_eg_E2.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_E2.TabIndex = 15;
            this.btn_eg_E2.Text = "E2";
            this.btn_eg_E2.UseVisualStyleBackColor = false;
            this.btn_eg_E2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_E1
            // 
            this.btn_eg_E1.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_E1.FlatAppearance.BorderSize = 0;
            this.btn_eg_E1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_E1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_E1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_E1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_E1.Location = new System.Drawing.Point(53, 283);
            this.btn_eg_E1.Name = "btn_eg_E1";
            this.btn_eg_E1.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_E1.TabIndex = 14;
            this.btn_eg_E1.Text = "E1";
            this.btn_eg_E1.UseVisualStyleBackColor = false;
            this.btn_eg_E1.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_F4
            // 
            this.btn_eg_F4.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_F4.FlatAppearance.BorderSize = 0;
            this.btn_eg_F4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_F4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_F4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_F4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_F4.Location = new System.Drawing.Point(247, 217);
            this.btn_eg_F4.Name = "btn_eg_F4";
            this.btn_eg_F4.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_F4.TabIndex = 13;
            this.btn_eg_F4.Text = "F4";
            this.btn_eg_F4.UseVisualStyleBackColor = false;
            this.btn_eg_F4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_F3
            // 
            this.btn_eg_F3.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_F3.FlatAppearance.BorderSize = 0;
            this.btn_eg_F3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_F3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_F3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_F3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_F3.Location = new System.Drawing.Point(181, 217);
            this.btn_eg_F3.Name = "btn_eg_F3";
            this.btn_eg_F3.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_F3.TabIndex = 12;
            this.btn_eg_F3.Text = "F3";
            this.btn_eg_F3.UseVisualStyleBackColor = false;
            this.btn_eg_F3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_F2
            // 
            this.btn_eg_F2.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_F2.FlatAppearance.BorderSize = 0;
            this.btn_eg_F2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_F2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_F2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_F2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_F2.Location = new System.Drawing.Point(119, 217);
            this.btn_eg_F2.Name = "btn_eg_F2";
            this.btn_eg_F2.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_F2.TabIndex = 11;
            this.btn_eg_F2.Text = "F2";
            this.btn_eg_F2.UseVisualStyleBackColor = false;
            this.btn_eg_F2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_eg_F1
            // 
            this.btn_eg_F1.BackColor = System.Drawing.Color.Transparent;
            this.btn_eg_F1.FlatAppearance.BorderSize = 0;
            this.btn_eg_F1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eg_F1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eg_F1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_eg_F1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_eg_F1.Location = new System.Drawing.Point(53, 217);
            this.btn_eg_F1.Name = "btn_eg_F1";
            this.btn_eg_F1.Size = new System.Drawing.Size(60, 60);
            this.btn_eg_F1.TabIndex = 10;
            this.btn_eg_F1.Text = "F1";
            this.btn_eg_F1.UseVisualStyleBackColor = false;
            this.btn_eg_F1.Click += new System.EventHandler(this.cekbangku);
            // 
            // kontentbangku_bp
            // 
            this.kontentbangku_bp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(168)))), ((int)(((byte)(120)))));
            this.kontentbangku_bp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.kontentbangku_bp.Controls.Add(this.button6);
            this.kontentbangku_bp.Controls.Add(this.button4);
            this.kontentbangku_bp.Controls.Add(this.panel7);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_A8);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_B7);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_C7);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_D7);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_E7);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_F7);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_A7);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_A9);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_A6);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_A5);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_B8);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_B9);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_B6);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_B5);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_C8);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_C9);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_C6);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_C5);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_D8);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_D9);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_D6);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_D5);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_E8);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_E9);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_E6);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_E5);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_F8);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_F9);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_F6);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_F5);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_A4);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_A3);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_A2);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_A1);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_B4);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_B3);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_B2);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_B1);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_C4);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_C3);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_C2);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_C1);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_D4);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_D3);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_D2);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_D1);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_E4);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_E3);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_E2);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_E1);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_F4);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_F3);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_F2);
            this.kontentbangku_bp.Controls.Add(this.btn_bp_F1);
            this.kontentbangku_bp.Controls.Add(this.label7);
            this.kontentbangku_bp.Controls.Add(this.panel9);
            this.kontentbangku_bp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kontentbangku_bp.Location = new System.Drawing.Point(370, 38);
            this.kontentbangku_bp.Name = "kontentbangku_bp";
            this.kontentbangku_bp.Size = new System.Drawing.Size(830, 705);
            this.kontentbangku_bp.TabIndex = 67;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(41)))), ((int)(((byte)(5)))));
            this.button6.Enabled = false;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button6.Location = new System.Drawing.Point(320, 627);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(182, 54);
            this.button6.TabIndex = 72;
            this.button6.Text = "Bayar";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.bayar);
            // 
            // button4
            // 
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(72)))), ((int)(((byte)(24)))));
            this.button4.Image = global::Project_UTS_v1.Properties.Resources.back;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(56, 39);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(110, 56);
            this.button4.TabIndex = 70;
            this.button4.Text = "Back";
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.backtofilm);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(41)))), ((int)(((byte)(5)))));
            this.panel7.Controls.Add(this.label6);
            this.panel7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.panel7.Location = new System.Drawing.Point(56, 126);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(711, 35);
            this.panel7.TabIndex = 69;
            this.panel7.Click += new System.EventHandler(this.panel6_Click_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(313, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 25);
            this.label6.TabIndex = 0;
            this.label6.Text = "Layar";
            // 
            // btn_bp_A8
            // 
            this.btn_bp_A8.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_A8.FlatAppearance.BorderSize = 0;
            this.btn_bp_A8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_A8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_A8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_A8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_A8.Location = new System.Drawing.Point(638, 547);
            this.btn_bp_A8.Name = "btn_bp_A8";
            this.btn_bp_A8.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_A8.TabIndex = 66;
            this.btn_bp_A8.Text = "A8";
            this.btn_bp_A8.UseVisualStyleBackColor = false;
            this.btn_bp_A8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_B7
            // 
            this.btn_bp_B7.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_B7.FlatAppearance.BorderSize = 0;
            this.btn_bp_B7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_B7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_B7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_B7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_B7.Location = new System.Drawing.Point(507, 481);
            this.btn_bp_B7.Name = "btn_bp_B7";
            this.btn_bp_B7.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_B7.TabIndex = 65;
            this.btn_bp_B7.Text = "B7";
            this.btn_bp_B7.UseVisualStyleBackColor = false;
            this.btn_bp_B7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_C7
            // 
            this.btn_bp_C7.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_C7.FlatAppearance.BorderSize = 0;
            this.btn_bp_C7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_C7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_C7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_C7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_C7.Location = new System.Drawing.Point(507, 415);
            this.btn_bp_C7.Name = "btn_bp_C7";
            this.btn_bp_C7.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_C7.TabIndex = 64;
            this.btn_bp_C7.Text = "C7";
            this.btn_bp_C7.UseVisualStyleBackColor = false;
            this.btn_bp_C7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_D7
            // 
            this.btn_bp_D7.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_D7.FlatAppearance.BorderSize = 0;
            this.btn_bp_D7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_D7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_D7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_D7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_D7.Location = new System.Drawing.Point(507, 349);
            this.btn_bp_D7.Name = "btn_bp_D7";
            this.btn_bp_D7.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_D7.TabIndex = 63;
            this.btn_bp_D7.Text = "D7";
            this.btn_bp_D7.UseVisualStyleBackColor = false;
            this.btn_bp_D7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_E7
            // 
            this.btn_bp_E7.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_E7.FlatAppearance.BorderSize = 0;
            this.btn_bp_E7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_E7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_E7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_E7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_E7.Location = new System.Drawing.Point(507, 283);
            this.btn_bp_E7.Name = "btn_bp_E7";
            this.btn_bp_E7.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_E7.TabIndex = 62;
            this.btn_bp_E7.Text = "E7";
            this.btn_bp_E7.UseVisualStyleBackColor = false;
            this.btn_bp_E7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_F7
            // 
            this.btn_bp_F7.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_F7.FlatAppearance.BorderSize = 0;
            this.btn_bp_F7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_F7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_F7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_F7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_F7.Location = new System.Drawing.Point(507, 217);
            this.btn_bp_F7.Name = "btn_bp_F7";
            this.btn_bp_F7.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_F7.TabIndex = 61;
            this.btn_bp_F7.Text = "F7";
            this.btn_bp_F7.UseVisualStyleBackColor = false;
            this.btn_bp_F7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_A7
            // 
            this.btn_bp_A7.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_A7.FlatAppearance.BorderSize = 0;
            this.btn_bp_A7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_A7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_A7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_A7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_A7.Location = new System.Drawing.Point(507, 547);
            this.btn_bp_A7.Name = "btn_bp_A7";
            this.btn_bp_A7.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_A7.TabIndex = 59;
            this.btn_bp_A7.Text = "A7";
            this.btn_bp_A7.UseVisualStyleBackColor = false;
            this.btn_bp_A7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_A9
            // 
            this.btn_bp_A9.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_A9.FlatAppearance.BorderSize = 0;
            this.btn_bp_A9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_A9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_A9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_A9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_A9.Location = new System.Drawing.Point(704, 547);
            this.btn_bp_A9.Name = "btn_bp_A9";
            this.btn_bp_A9.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_A9.TabIndex = 57;
            this.btn_bp_A9.Text = "A9";
            this.btn_bp_A9.UseVisualStyleBackColor = false;
            this.btn_bp_A9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_A6
            // 
            this.btn_bp_A6.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_A6.FlatAppearance.BorderSize = 0;
            this.btn_bp_A6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_A6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_A6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_A6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_A6.Location = new System.Drawing.Point(437, 547);
            this.btn_bp_A6.Name = "btn_bp_A6";
            this.btn_bp_A6.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_A6.TabIndex = 55;
            this.btn_bp_A6.Text = "A6";
            this.btn_bp_A6.UseVisualStyleBackColor = false;
            this.btn_bp_A6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_A5
            // 
            this.btn_bp_A5.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_A5.FlatAppearance.BorderSize = 0;
            this.btn_bp_A5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_A5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_A5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_A5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_A5.Location = new System.Drawing.Point(371, 547);
            this.btn_bp_A5.Name = "btn_bp_A5";
            this.btn_bp_A5.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_A5.TabIndex = 54;
            this.btn_bp_A5.Text = "A5";
            this.btn_bp_A5.UseVisualStyleBackColor = false;
            this.btn_bp_A5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_B8
            // 
            this.btn_bp_B8.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_B8.FlatAppearance.BorderSize = 0;
            this.btn_bp_B8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_B8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_B8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_B8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_B8.Location = new System.Drawing.Point(638, 481);
            this.btn_bp_B8.Name = "btn_bp_B8";
            this.btn_bp_B8.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_B8.TabIndex = 53;
            this.btn_bp_B8.Text = "B8";
            this.btn_bp_B8.UseVisualStyleBackColor = false;
            this.btn_bp_B8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_B9
            // 
            this.btn_bp_B9.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_B9.FlatAppearance.BorderSize = 0;
            this.btn_bp_B9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_B9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_B9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_B9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_B9.Location = new System.Drawing.Point(704, 481);
            this.btn_bp_B9.Name = "btn_bp_B9";
            this.btn_bp_B9.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_B9.TabIndex = 52;
            this.btn_bp_B9.Text = "B9";
            this.btn_bp_B9.UseVisualStyleBackColor = false;
            this.btn_bp_B9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_B6
            // 
            this.btn_bp_B6.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_B6.FlatAppearance.BorderSize = 0;
            this.btn_bp_B6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_B6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_B6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_B6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_B6.Location = new System.Drawing.Point(437, 481);
            this.btn_bp_B6.Name = "btn_bp_B6";
            this.btn_bp_B6.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_B6.TabIndex = 51;
            this.btn_bp_B6.Text = "B6";
            this.btn_bp_B6.UseVisualStyleBackColor = false;
            this.btn_bp_B6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_B5
            // 
            this.btn_bp_B5.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_B5.FlatAppearance.BorderSize = 0;
            this.btn_bp_B5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_B5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_B5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_B5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_B5.Location = new System.Drawing.Point(371, 481);
            this.btn_bp_B5.Name = "btn_bp_B5";
            this.btn_bp_B5.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_B5.TabIndex = 50;
            this.btn_bp_B5.Text = "B5";
            this.btn_bp_B5.UseVisualStyleBackColor = false;
            this.btn_bp_B5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_C8
            // 
            this.btn_bp_C8.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_C8.FlatAppearance.BorderSize = 0;
            this.btn_bp_C8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_C8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_C8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_C8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_C8.Location = new System.Drawing.Point(638, 415);
            this.btn_bp_C8.Name = "btn_bp_C8";
            this.btn_bp_C8.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_C8.TabIndex = 49;
            this.btn_bp_C8.Text = "C8";
            this.btn_bp_C8.UseVisualStyleBackColor = false;
            this.btn_bp_C8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_C9
            // 
            this.btn_bp_C9.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_C9.FlatAppearance.BorderSize = 0;
            this.btn_bp_C9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_C9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_C9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_C9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_C9.Location = new System.Drawing.Point(704, 415);
            this.btn_bp_C9.Name = "btn_bp_C9";
            this.btn_bp_C9.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_C9.TabIndex = 48;
            this.btn_bp_C9.Text = "C9";
            this.btn_bp_C9.UseVisualStyleBackColor = false;
            this.btn_bp_C9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_C6
            // 
            this.btn_bp_C6.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_C6.FlatAppearance.BorderSize = 0;
            this.btn_bp_C6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_C6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_C6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_C6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_C6.Location = new System.Drawing.Point(437, 415);
            this.btn_bp_C6.Name = "btn_bp_C6";
            this.btn_bp_C6.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_C6.TabIndex = 47;
            this.btn_bp_C6.Text = "C6";
            this.btn_bp_C6.UseVisualStyleBackColor = false;
            this.btn_bp_C6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_C5
            // 
            this.btn_bp_C5.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_C5.FlatAppearance.BorderSize = 0;
            this.btn_bp_C5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_C5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_C5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_C5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_C5.Location = new System.Drawing.Point(371, 415);
            this.btn_bp_C5.Name = "btn_bp_C5";
            this.btn_bp_C5.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_C5.TabIndex = 46;
            this.btn_bp_C5.Text = "C5";
            this.btn_bp_C5.UseVisualStyleBackColor = false;
            this.btn_bp_C5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_D8
            // 
            this.btn_bp_D8.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_D8.FlatAppearance.BorderSize = 0;
            this.btn_bp_D8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_D8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_D8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_D8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_D8.Location = new System.Drawing.Point(638, 349);
            this.btn_bp_D8.Name = "btn_bp_D8";
            this.btn_bp_D8.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_D8.TabIndex = 45;
            this.btn_bp_D8.Text = "D8";
            this.btn_bp_D8.UseVisualStyleBackColor = false;
            this.btn_bp_D8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_D9
            // 
            this.btn_bp_D9.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_D9.FlatAppearance.BorderSize = 0;
            this.btn_bp_D9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_D9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_D9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_D9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_D9.Location = new System.Drawing.Point(704, 349);
            this.btn_bp_D9.Name = "btn_bp_D9";
            this.btn_bp_D9.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_D9.TabIndex = 44;
            this.btn_bp_D9.Text = "D9";
            this.btn_bp_D9.UseVisualStyleBackColor = false;
            this.btn_bp_D9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_D6
            // 
            this.btn_bp_D6.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_D6.FlatAppearance.BorderSize = 0;
            this.btn_bp_D6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_D6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_D6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_D6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_D6.Location = new System.Drawing.Point(437, 349);
            this.btn_bp_D6.Name = "btn_bp_D6";
            this.btn_bp_D6.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_D6.TabIndex = 43;
            this.btn_bp_D6.Text = "D6";
            this.btn_bp_D6.UseVisualStyleBackColor = false;
            this.btn_bp_D6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_D5
            // 
            this.btn_bp_D5.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_D5.FlatAppearance.BorderSize = 0;
            this.btn_bp_D5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_D5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_D5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_D5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_D5.Location = new System.Drawing.Point(371, 349);
            this.btn_bp_D5.Name = "btn_bp_D5";
            this.btn_bp_D5.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_D5.TabIndex = 42;
            this.btn_bp_D5.Text = "D5";
            this.btn_bp_D5.UseVisualStyleBackColor = false;
            this.btn_bp_D5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_E8
            // 
            this.btn_bp_E8.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_E8.FlatAppearance.BorderSize = 0;
            this.btn_bp_E8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_E8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_E8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_E8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_E8.Location = new System.Drawing.Point(638, 283);
            this.btn_bp_E8.Name = "btn_bp_E8";
            this.btn_bp_E8.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_E8.TabIndex = 41;
            this.btn_bp_E8.Text = "E8";
            this.btn_bp_E8.UseVisualStyleBackColor = false;
            this.btn_bp_E8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_E9
            // 
            this.btn_bp_E9.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_E9.FlatAppearance.BorderSize = 0;
            this.btn_bp_E9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_E9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_E9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_E9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_E9.Location = new System.Drawing.Point(704, 283);
            this.btn_bp_E9.Name = "btn_bp_E9";
            this.btn_bp_E9.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_E9.TabIndex = 40;
            this.btn_bp_E9.Text = "E9";
            this.btn_bp_E9.UseVisualStyleBackColor = false;
            this.btn_bp_E9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_E6
            // 
            this.btn_bp_E6.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_E6.FlatAppearance.BorderSize = 0;
            this.btn_bp_E6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_E6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_E6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_E6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_E6.Location = new System.Drawing.Point(437, 283);
            this.btn_bp_E6.Name = "btn_bp_E6";
            this.btn_bp_E6.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_E6.TabIndex = 39;
            this.btn_bp_E6.Text = "E6";
            this.btn_bp_E6.UseVisualStyleBackColor = false;
            this.btn_bp_E6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_E5
            // 
            this.btn_bp_E5.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_E5.FlatAppearance.BorderSize = 0;
            this.btn_bp_E5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_E5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_E5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_E5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_E5.Location = new System.Drawing.Point(371, 283);
            this.btn_bp_E5.Name = "btn_bp_E5";
            this.btn_bp_E5.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_E5.TabIndex = 38;
            this.btn_bp_E5.Text = "E5";
            this.btn_bp_E5.UseVisualStyleBackColor = false;
            this.btn_bp_E5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_F8
            // 
            this.btn_bp_F8.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_F8.FlatAppearance.BorderSize = 0;
            this.btn_bp_F8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_F8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_F8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_F8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_F8.Location = new System.Drawing.Point(638, 217);
            this.btn_bp_F8.Name = "btn_bp_F8";
            this.btn_bp_F8.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_F8.TabIndex = 37;
            this.btn_bp_F8.Text = "F8";
            this.btn_bp_F8.UseVisualStyleBackColor = false;
            this.btn_bp_F8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_F9
            // 
            this.btn_bp_F9.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_F9.FlatAppearance.BorderSize = 0;
            this.btn_bp_F9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_F9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_F9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_F9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_F9.Location = new System.Drawing.Point(704, 217);
            this.btn_bp_F9.Name = "btn_bp_F9";
            this.btn_bp_F9.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_F9.TabIndex = 36;
            this.btn_bp_F9.Text = "F9";
            this.btn_bp_F9.UseVisualStyleBackColor = false;
            this.btn_bp_F9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_F6
            // 
            this.btn_bp_F6.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_F6.FlatAppearance.BorderSize = 0;
            this.btn_bp_F6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_F6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_F6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_F6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_F6.Location = new System.Drawing.Point(437, 217);
            this.btn_bp_F6.Name = "btn_bp_F6";
            this.btn_bp_F6.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_F6.TabIndex = 35;
            this.btn_bp_F6.Text = "F6";
            this.btn_bp_F6.UseVisualStyleBackColor = false;
            this.btn_bp_F6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_F5
            // 
            this.btn_bp_F5.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_F5.FlatAppearance.BorderSize = 0;
            this.btn_bp_F5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_F5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_F5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_F5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_F5.Location = new System.Drawing.Point(371, 217);
            this.btn_bp_F5.Name = "btn_bp_F5";
            this.btn_bp_F5.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_F5.TabIndex = 34;
            this.btn_bp_F5.Text = "F5";
            this.btn_bp_F5.UseVisualStyleBackColor = false;
            this.btn_bp_F5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_A4
            // 
            this.btn_bp_A4.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_A4.FlatAppearance.BorderSize = 0;
            this.btn_bp_A4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_A4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_A4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_A4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_A4.Location = new System.Drawing.Point(247, 547);
            this.btn_bp_A4.Name = "btn_bp_A4";
            this.btn_bp_A4.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_A4.TabIndex = 33;
            this.btn_bp_A4.Text = "A4";
            this.btn_bp_A4.UseVisualStyleBackColor = false;
            this.btn_bp_A4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_A3
            // 
            this.btn_bp_A3.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_A3.FlatAppearance.BorderSize = 0;
            this.btn_bp_A3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_A3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_A3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_A3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_A3.Location = new System.Drawing.Point(181, 547);
            this.btn_bp_A3.Name = "btn_bp_A3";
            this.btn_bp_A3.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_A3.TabIndex = 32;
            this.btn_bp_A3.Text = "A3";
            this.btn_bp_A3.UseVisualStyleBackColor = false;
            this.btn_bp_A3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_A2
            // 
            this.btn_bp_A2.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_A2.FlatAppearance.BorderSize = 0;
            this.btn_bp_A2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_A2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_A2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_A2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_A2.Location = new System.Drawing.Point(119, 547);
            this.btn_bp_A2.Name = "btn_bp_A2";
            this.btn_bp_A2.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_A2.TabIndex = 31;
            this.btn_bp_A2.Text = "A2";
            this.btn_bp_A2.UseVisualStyleBackColor = false;
            this.btn_bp_A2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_A1
            // 
            this.btn_bp_A1.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_A1.FlatAppearance.BorderSize = 0;
            this.btn_bp_A1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_A1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_A1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_A1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_A1.Location = new System.Drawing.Point(53, 547);
            this.btn_bp_A1.Name = "btn_bp_A1";
            this.btn_bp_A1.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_A1.TabIndex = 30;
            this.btn_bp_A1.Text = "A1";
            this.btn_bp_A1.UseVisualStyleBackColor = false;
            this.btn_bp_A1.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_B4
            // 
            this.btn_bp_B4.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_B4.FlatAppearance.BorderSize = 0;
            this.btn_bp_B4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_B4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_B4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_B4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_B4.Location = new System.Drawing.Point(247, 481);
            this.btn_bp_B4.Name = "btn_bp_B4";
            this.btn_bp_B4.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_B4.TabIndex = 29;
            this.btn_bp_B4.Text = "B4";
            this.btn_bp_B4.UseVisualStyleBackColor = false;
            this.btn_bp_B4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_B3
            // 
            this.btn_bp_B3.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_B3.FlatAppearance.BorderSize = 0;
            this.btn_bp_B3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_B3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_B3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_B3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_B3.Location = new System.Drawing.Point(181, 481);
            this.btn_bp_B3.Name = "btn_bp_B3";
            this.btn_bp_B3.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_B3.TabIndex = 28;
            this.btn_bp_B3.Text = "B3";
            this.btn_bp_B3.UseVisualStyleBackColor = false;
            this.btn_bp_B3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_B2
            // 
            this.btn_bp_B2.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_B2.FlatAppearance.BorderSize = 0;
            this.btn_bp_B2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_B2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_B2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_B2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_B2.Location = new System.Drawing.Point(119, 481);
            this.btn_bp_B2.Name = "btn_bp_B2";
            this.btn_bp_B2.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_B2.TabIndex = 27;
            this.btn_bp_B2.Text = "B2";
            this.btn_bp_B2.UseVisualStyleBackColor = false;
            this.btn_bp_B2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_B1
            // 
            this.btn_bp_B1.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_B1.FlatAppearance.BorderSize = 0;
            this.btn_bp_B1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_B1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_B1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_B1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_B1.Location = new System.Drawing.Point(53, 481);
            this.btn_bp_B1.Name = "btn_bp_B1";
            this.btn_bp_B1.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_B1.TabIndex = 26;
            this.btn_bp_B1.Text = "B1";
            this.btn_bp_B1.UseVisualStyleBackColor = false;
            this.btn_bp_B1.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_C4
            // 
            this.btn_bp_C4.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_C4.FlatAppearance.BorderSize = 0;
            this.btn_bp_C4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_C4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_C4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_C4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_C4.Location = new System.Drawing.Point(247, 415);
            this.btn_bp_C4.Name = "btn_bp_C4";
            this.btn_bp_C4.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_C4.TabIndex = 25;
            this.btn_bp_C4.Text = "C4";
            this.btn_bp_C4.UseVisualStyleBackColor = false;
            this.btn_bp_C4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_C3
            // 
            this.btn_bp_C3.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_C3.FlatAppearance.BorderSize = 0;
            this.btn_bp_C3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_C3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_C3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_C3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_C3.Location = new System.Drawing.Point(181, 415);
            this.btn_bp_C3.Name = "btn_bp_C3";
            this.btn_bp_C3.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_C3.TabIndex = 24;
            this.btn_bp_C3.Text = "C3";
            this.btn_bp_C3.UseVisualStyleBackColor = false;
            this.btn_bp_C3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_C2
            // 
            this.btn_bp_C2.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_C2.FlatAppearance.BorderSize = 0;
            this.btn_bp_C2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_C2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_C2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_C2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_C2.Location = new System.Drawing.Point(119, 415);
            this.btn_bp_C2.Name = "btn_bp_C2";
            this.btn_bp_C2.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_C2.TabIndex = 23;
            this.btn_bp_C2.Text = "C2";
            this.btn_bp_C2.UseVisualStyleBackColor = false;
            this.btn_bp_C2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_C1
            // 
            this.btn_bp_C1.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_C1.FlatAppearance.BorderSize = 0;
            this.btn_bp_C1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_C1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_C1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_C1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_C1.Location = new System.Drawing.Point(53, 415);
            this.btn_bp_C1.Name = "btn_bp_C1";
            this.btn_bp_C1.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_C1.TabIndex = 22;
            this.btn_bp_C1.Text = "C1";
            this.btn_bp_C1.UseVisualStyleBackColor = false;
            this.btn_bp_C1.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_D4
            // 
            this.btn_bp_D4.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_D4.FlatAppearance.BorderSize = 0;
            this.btn_bp_D4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_D4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_D4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_D4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_D4.Location = new System.Drawing.Point(247, 349);
            this.btn_bp_D4.Name = "btn_bp_D4";
            this.btn_bp_D4.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_D4.TabIndex = 21;
            this.btn_bp_D4.Text = "D4";
            this.btn_bp_D4.UseVisualStyleBackColor = false;
            this.btn_bp_D4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_D3
            // 
            this.btn_bp_D3.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_D3.FlatAppearance.BorderSize = 0;
            this.btn_bp_D3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_D3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_D3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_D3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_D3.Location = new System.Drawing.Point(181, 349);
            this.btn_bp_D3.Name = "btn_bp_D3";
            this.btn_bp_D3.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_D3.TabIndex = 20;
            this.btn_bp_D3.Text = "D3";
            this.btn_bp_D3.UseVisualStyleBackColor = false;
            this.btn_bp_D3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_D2
            // 
            this.btn_bp_D2.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_D2.FlatAppearance.BorderSize = 0;
            this.btn_bp_D2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_D2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_D2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_D2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_D2.Location = new System.Drawing.Point(119, 349);
            this.btn_bp_D2.Name = "btn_bp_D2";
            this.btn_bp_D2.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_D2.TabIndex = 19;
            this.btn_bp_D2.Text = "D2";
            this.btn_bp_D2.UseVisualStyleBackColor = false;
            this.btn_bp_D2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_D1
            // 
            this.btn_bp_D1.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_D1.FlatAppearance.BorderSize = 0;
            this.btn_bp_D1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_D1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_D1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_D1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_D1.Location = new System.Drawing.Point(53, 349);
            this.btn_bp_D1.Name = "btn_bp_D1";
            this.btn_bp_D1.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_D1.TabIndex = 18;
            this.btn_bp_D1.Text = "D1";
            this.btn_bp_D1.UseVisualStyleBackColor = false;
            this.btn_bp_D1.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_E4
            // 
            this.btn_bp_E4.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_E4.FlatAppearance.BorderSize = 0;
            this.btn_bp_E4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_E4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_E4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_E4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_E4.Location = new System.Drawing.Point(247, 283);
            this.btn_bp_E4.Name = "btn_bp_E4";
            this.btn_bp_E4.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_E4.TabIndex = 17;
            this.btn_bp_E4.Text = "E4";
            this.btn_bp_E4.UseVisualStyleBackColor = false;
            this.btn_bp_E4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_E3
            // 
            this.btn_bp_E3.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_E3.FlatAppearance.BorderSize = 0;
            this.btn_bp_E3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_E3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_E3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_E3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_E3.Location = new System.Drawing.Point(181, 283);
            this.btn_bp_E3.Name = "btn_bp_E3";
            this.btn_bp_E3.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_E3.TabIndex = 16;
            this.btn_bp_E3.Text = "E3";
            this.btn_bp_E3.UseVisualStyleBackColor = false;
            this.btn_bp_E3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_E2
            // 
            this.btn_bp_E2.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_E2.FlatAppearance.BorderSize = 0;
            this.btn_bp_E2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_E2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_E2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_E2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_E2.Location = new System.Drawing.Point(119, 283);
            this.btn_bp_E2.Name = "btn_bp_E2";
            this.btn_bp_E2.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_E2.TabIndex = 15;
            this.btn_bp_E2.Text = "E2";
            this.btn_bp_E2.UseVisualStyleBackColor = false;
            this.btn_bp_E2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_E1
            // 
            this.btn_bp_E1.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_E1.FlatAppearance.BorderSize = 0;
            this.btn_bp_E1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_E1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_E1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_E1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_E1.Location = new System.Drawing.Point(53, 283);
            this.btn_bp_E1.Name = "btn_bp_E1";
            this.btn_bp_E1.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_E1.TabIndex = 14;
            this.btn_bp_E1.Text = "E1";
            this.btn_bp_E1.UseVisualStyleBackColor = false;
            this.btn_bp_E1.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_F4
            // 
            this.btn_bp_F4.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_F4.FlatAppearance.BorderSize = 0;
            this.btn_bp_F4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_F4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_F4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_F4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_F4.Location = new System.Drawing.Point(247, 217);
            this.btn_bp_F4.Name = "btn_bp_F4";
            this.btn_bp_F4.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_F4.TabIndex = 13;
            this.btn_bp_F4.Text = "F4";
            this.btn_bp_F4.UseVisualStyleBackColor = false;
            this.btn_bp_F4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_F3
            // 
            this.btn_bp_F3.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_F3.FlatAppearance.BorderSize = 0;
            this.btn_bp_F3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_F3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_F3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_F3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_F3.Location = new System.Drawing.Point(181, 217);
            this.btn_bp_F3.Name = "btn_bp_F3";
            this.btn_bp_F3.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_F3.TabIndex = 12;
            this.btn_bp_F3.Text = "F3";
            this.btn_bp_F3.UseVisualStyleBackColor = false;
            this.btn_bp_F3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_F2
            // 
            this.btn_bp_F2.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_F2.FlatAppearance.BorderSize = 0;
            this.btn_bp_F2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_F2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_F2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_F2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_F2.Location = new System.Drawing.Point(119, 217);
            this.btn_bp_F2.Name = "btn_bp_F2";
            this.btn_bp_F2.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_F2.TabIndex = 11;
            this.btn_bp_F2.Text = "F2";
            this.btn_bp_F2.UseVisualStyleBackColor = false;
            this.btn_bp_F2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_bp_F1
            // 
            this.btn_bp_F1.BackColor = System.Drawing.Color.Transparent;
            this.btn_bp_F1.FlatAppearance.BorderSize = 0;
            this.btn_bp_F1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bp_F1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bp_F1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_bp_F1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_bp_F1.Location = new System.Drawing.Point(53, 217);
            this.btn_bp_F1.Name = "btn_bp_F1";
            this.btn_bp_F1.Size = new System.Drawing.Size(60, 60);
            this.btn_bp_F1.TabIndex = 10;
            this.btn_bp_F1.Text = "F1";
            this.btn_bp_F1.UseVisualStyleBackColor = false;
            this.btn_bp_F1.Click += new System.EventHandler(this.cekbangku);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(72)))), ((int)(((byte)(24)))));
            this.label7.Location = new System.Drawing.Point(237, 39);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(345, 56);
            this.label7.TabIndex = 9;
            this.label7.Text = "Black Pather";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(72)))), ((int)(((byte)(24)))));
            this.panel9.Location = new System.Drawing.Point(336, 95);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(150, 2);
            this.panel9.TabIndex = 8;
            // 
            // kontentbangku_ff
            // 
            this.kontentbangku_ff.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(168)))), ((int)(((byte)(120)))));
            this.kontentbangku_ff.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.kontentbangku_ff.Controls.Add(this.button1);
            this.kontentbangku_ff.Controls.Add(this.button5);
            this.kontentbangku_ff.Controls.Add(this.panel8);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_A8);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_B7);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_C7);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_D7);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_E7);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_F7);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_A7);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_A9);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_A6);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_A5);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_B8);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_B9);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_B6);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_B5);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_C8);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_C9);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_C6);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_C5);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_D8);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_D9);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_D6);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_D5);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_E8);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_E9);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_E6);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_E5);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_F8);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_F9);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_F6);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_F5);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_A4);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_A3);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_A2);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_A1);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_B4);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_B3);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_B2);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_B1);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_C4);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_C3);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_C2);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_C1);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_D4);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_D3);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_D2);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_D1);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_E4);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_E3);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_E2);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_E1);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_F4);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_F3);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_F2);
            this.kontentbangku_ff.Controls.Add(this.btn_ff_F1);
            this.kontentbangku_ff.Controls.Add(this.label12);
            this.kontentbangku_ff.Controls.Add(this.panel12);
            this.kontentbangku_ff.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kontentbangku_ff.Location = new System.Drawing.Point(370, 38);
            this.kontentbangku_ff.Name = "kontentbangku_ff";
            this.kontentbangku_ff.Size = new System.Drawing.Size(830, 705);
            this.kontentbangku_ff.TabIndex = 68;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(41)))), ((int)(((byte)(5)))));
            this.button1.Enabled = false;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(317, 627);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(182, 54);
            this.button1.TabIndex = 71;
            this.button1.Text = "Bayar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.bayar);
            // 
            // button5
            // 
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(72)))), ((int)(((byte)(24)))));
            this.button5.Image = global::Project_UTS_v1.Properties.Resources.back;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(53, 38);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(110, 56);
            this.button5.TabIndex = 72;
            this.button5.Text = "Back";
            this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.backtofilm);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(41)))), ((int)(((byte)(5)))));
            this.panel8.Controls.Add(this.label8);
            this.panel8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.panel8.Location = new System.Drawing.Point(53, 132);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(711, 35);
            this.panel8.TabIndex = 71;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(313, 6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 25);
            this.label8.TabIndex = 0;
            this.label8.Text = "Layar";
            // 
            // btn_ff_A8
            // 
            this.btn_ff_A8.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_A8.FlatAppearance.BorderSize = 0;
            this.btn_ff_A8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_A8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_A8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_A8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_A8.Location = new System.Drawing.Point(638, 547);
            this.btn_ff_A8.Name = "btn_ff_A8";
            this.btn_ff_A8.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_A8.TabIndex = 66;
            this.btn_ff_A8.Text = "A8";
            this.btn_ff_A8.UseVisualStyleBackColor = false;
            this.btn_ff_A8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_B7
            // 
            this.btn_ff_B7.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_B7.FlatAppearance.BorderSize = 0;
            this.btn_ff_B7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_B7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_B7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_B7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_B7.Location = new System.Drawing.Point(507, 481);
            this.btn_ff_B7.Name = "btn_ff_B7";
            this.btn_ff_B7.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_B7.TabIndex = 65;
            this.btn_ff_B7.Text = "B7";
            this.btn_ff_B7.UseVisualStyleBackColor = false;
            this.btn_ff_B7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_C7
            // 
            this.btn_ff_C7.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_C7.FlatAppearance.BorderSize = 0;
            this.btn_ff_C7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_C7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_C7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_C7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_C7.Location = new System.Drawing.Point(507, 415);
            this.btn_ff_C7.Name = "btn_ff_C7";
            this.btn_ff_C7.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_C7.TabIndex = 64;
            this.btn_ff_C7.Text = "C7";
            this.btn_ff_C7.UseVisualStyleBackColor = false;
            this.btn_ff_C7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_D7
            // 
            this.btn_ff_D7.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_D7.FlatAppearance.BorderSize = 0;
            this.btn_ff_D7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_D7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_D7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_D7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_D7.Location = new System.Drawing.Point(507, 349);
            this.btn_ff_D7.Name = "btn_ff_D7";
            this.btn_ff_D7.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_D7.TabIndex = 63;
            this.btn_ff_D7.Text = "D7";
            this.btn_ff_D7.UseVisualStyleBackColor = false;
            this.btn_ff_D7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_E7
            // 
            this.btn_ff_E7.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_E7.FlatAppearance.BorderSize = 0;
            this.btn_ff_E7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_E7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_E7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_E7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_E7.Location = new System.Drawing.Point(507, 283);
            this.btn_ff_E7.Name = "btn_ff_E7";
            this.btn_ff_E7.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_E7.TabIndex = 62;
            this.btn_ff_E7.Text = "E7";
            this.btn_ff_E7.UseVisualStyleBackColor = false;
            this.btn_ff_E7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_F7
            // 
            this.btn_ff_F7.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_F7.FlatAppearance.BorderSize = 0;
            this.btn_ff_F7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_F7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_F7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_F7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_F7.Location = new System.Drawing.Point(507, 217);
            this.btn_ff_F7.Name = "btn_ff_F7";
            this.btn_ff_F7.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_F7.TabIndex = 61;
            this.btn_ff_F7.Text = "F7";
            this.btn_ff_F7.UseVisualStyleBackColor = false;
            this.btn_ff_F7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_A7
            // 
            this.btn_ff_A7.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_A7.FlatAppearance.BorderSize = 0;
            this.btn_ff_A7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_A7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_A7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_A7.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_A7.Location = new System.Drawing.Point(507, 547);
            this.btn_ff_A7.Name = "btn_ff_A7";
            this.btn_ff_A7.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_A7.TabIndex = 59;
            this.btn_ff_A7.Text = "A7";
            this.btn_ff_A7.UseVisualStyleBackColor = false;
            this.btn_ff_A7.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_A9
            // 
            this.btn_ff_A9.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_A9.FlatAppearance.BorderSize = 0;
            this.btn_ff_A9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_A9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_A9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_A9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_A9.Location = new System.Drawing.Point(704, 547);
            this.btn_ff_A9.Name = "btn_ff_A9";
            this.btn_ff_A9.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_A9.TabIndex = 57;
            this.btn_ff_A9.Text = "A9";
            this.btn_ff_A9.UseVisualStyleBackColor = false;
            this.btn_ff_A9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_A6
            // 
            this.btn_ff_A6.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_A6.FlatAppearance.BorderSize = 0;
            this.btn_ff_A6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_A6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_A6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_A6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_A6.Location = new System.Drawing.Point(437, 547);
            this.btn_ff_A6.Name = "btn_ff_A6";
            this.btn_ff_A6.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_A6.TabIndex = 55;
            this.btn_ff_A6.Text = "A6";
            this.btn_ff_A6.UseVisualStyleBackColor = false;
            this.btn_ff_A6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_A5
            // 
            this.btn_ff_A5.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_A5.FlatAppearance.BorderSize = 0;
            this.btn_ff_A5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_A5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_A5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_A5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_A5.Location = new System.Drawing.Point(371, 547);
            this.btn_ff_A5.Name = "btn_ff_A5";
            this.btn_ff_A5.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_A5.TabIndex = 54;
            this.btn_ff_A5.Text = "A5";
            this.btn_ff_A5.UseVisualStyleBackColor = false;
            this.btn_ff_A5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_B8
            // 
            this.btn_ff_B8.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_B8.FlatAppearance.BorderSize = 0;
            this.btn_ff_B8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_B8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_B8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_B8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_B8.Location = new System.Drawing.Point(638, 481);
            this.btn_ff_B8.Name = "btn_ff_B8";
            this.btn_ff_B8.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_B8.TabIndex = 53;
            this.btn_ff_B8.Text = "B8";
            this.btn_ff_B8.UseVisualStyleBackColor = false;
            this.btn_ff_B8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_B9
            // 
            this.btn_ff_B9.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_B9.FlatAppearance.BorderSize = 0;
            this.btn_ff_B9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_B9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_B9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_B9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_B9.Location = new System.Drawing.Point(704, 481);
            this.btn_ff_B9.Name = "btn_ff_B9";
            this.btn_ff_B9.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_B9.TabIndex = 52;
            this.btn_ff_B9.Text = "B9";
            this.btn_ff_B9.UseVisualStyleBackColor = false;
            this.btn_ff_B9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_B6
            // 
            this.btn_ff_B6.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_B6.FlatAppearance.BorderSize = 0;
            this.btn_ff_B6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_B6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_B6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_B6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_B6.Location = new System.Drawing.Point(437, 481);
            this.btn_ff_B6.Name = "btn_ff_B6";
            this.btn_ff_B6.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_B6.TabIndex = 51;
            this.btn_ff_B6.Text = "B6";
            this.btn_ff_B6.UseVisualStyleBackColor = false;
            this.btn_ff_B6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_B5
            // 
            this.btn_ff_B5.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_B5.FlatAppearance.BorderSize = 0;
            this.btn_ff_B5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_B5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_B5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_B5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_B5.Location = new System.Drawing.Point(371, 481);
            this.btn_ff_B5.Name = "btn_ff_B5";
            this.btn_ff_B5.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_B5.TabIndex = 50;
            this.btn_ff_B5.Text = "B5";
            this.btn_ff_B5.UseVisualStyleBackColor = false;
            this.btn_ff_B5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_C8
            // 
            this.btn_ff_C8.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_C8.FlatAppearance.BorderSize = 0;
            this.btn_ff_C8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_C8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_C8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_C8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_C8.Location = new System.Drawing.Point(638, 415);
            this.btn_ff_C8.Name = "btn_ff_C8";
            this.btn_ff_C8.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_C8.TabIndex = 49;
            this.btn_ff_C8.Text = "C8";
            this.btn_ff_C8.UseVisualStyleBackColor = false;
            this.btn_ff_C8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_C9
            // 
            this.btn_ff_C9.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_C9.FlatAppearance.BorderSize = 0;
            this.btn_ff_C9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_C9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_C9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_C9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_C9.Location = new System.Drawing.Point(704, 415);
            this.btn_ff_C9.Name = "btn_ff_C9";
            this.btn_ff_C9.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_C9.TabIndex = 48;
            this.btn_ff_C9.Text = "C9";
            this.btn_ff_C9.UseVisualStyleBackColor = false;
            this.btn_ff_C9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_C6
            // 
            this.btn_ff_C6.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_C6.FlatAppearance.BorderSize = 0;
            this.btn_ff_C6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_C6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_C6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_C6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_C6.Location = new System.Drawing.Point(437, 415);
            this.btn_ff_C6.Name = "btn_ff_C6";
            this.btn_ff_C6.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_C6.TabIndex = 47;
            this.btn_ff_C6.Text = "C6";
            this.btn_ff_C6.UseVisualStyleBackColor = false;
            this.btn_ff_C6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_C5
            // 
            this.btn_ff_C5.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_C5.FlatAppearance.BorderSize = 0;
            this.btn_ff_C5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_C5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_C5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_C5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_C5.Location = new System.Drawing.Point(371, 415);
            this.btn_ff_C5.Name = "btn_ff_C5";
            this.btn_ff_C5.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_C5.TabIndex = 46;
            this.btn_ff_C5.Text = "C5";
            this.btn_ff_C5.UseVisualStyleBackColor = false;
            this.btn_ff_C5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_D8
            // 
            this.btn_ff_D8.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_D8.FlatAppearance.BorderSize = 0;
            this.btn_ff_D8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_D8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_D8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_D8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_D8.Location = new System.Drawing.Point(638, 349);
            this.btn_ff_D8.Name = "btn_ff_D8";
            this.btn_ff_D8.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_D8.TabIndex = 45;
            this.btn_ff_D8.Text = "D8";
            this.btn_ff_D8.UseVisualStyleBackColor = false;
            this.btn_ff_D8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_D9
            // 
            this.btn_ff_D9.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_D9.FlatAppearance.BorderSize = 0;
            this.btn_ff_D9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_D9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_D9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_D9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_D9.Location = new System.Drawing.Point(704, 349);
            this.btn_ff_D9.Name = "btn_ff_D9";
            this.btn_ff_D9.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_D9.TabIndex = 44;
            this.btn_ff_D9.Text = "D9";
            this.btn_ff_D9.UseVisualStyleBackColor = false;
            this.btn_ff_D9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_D6
            // 
            this.btn_ff_D6.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_D6.FlatAppearance.BorderSize = 0;
            this.btn_ff_D6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_D6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_D6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_D6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_D6.Location = new System.Drawing.Point(437, 349);
            this.btn_ff_D6.Name = "btn_ff_D6";
            this.btn_ff_D6.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_D6.TabIndex = 43;
            this.btn_ff_D6.Text = "D6";
            this.btn_ff_D6.UseVisualStyleBackColor = false;
            this.btn_ff_D6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_D5
            // 
            this.btn_ff_D5.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_D5.FlatAppearance.BorderSize = 0;
            this.btn_ff_D5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_D5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_D5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_D5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_D5.Location = new System.Drawing.Point(371, 349);
            this.btn_ff_D5.Name = "btn_ff_D5";
            this.btn_ff_D5.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_D5.TabIndex = 42;
            this.btn_ff_D5.Text = "D5";
            this.btn_ff_D5.UseVisualStyleBackColor = false;
            this.btn_ff_D5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_E8
            // 
            this.btn_ff_E8.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_E8.FlatAppearance.BorderSize = 0;
            this.btn_ff_E8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_E8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_E8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_E8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_E8.Location = new System.Drawing.Point(638, 283);
            this.btn_ff_E8.Name = "btn_ff_E8";
            this.btn_ff_E8.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_E8.TabIndex = 41;
            this.btn_ff_E8.Text = "E8";
            this.btn_ff_E8.UseVisualStyleBackColor = false;
            this.btn_ff_E8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_E9
            // 
            this.btn_ff_E9.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_E9.FlatAppearance.BorderSize = 0;
            this.btn_ff_E9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_E9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_E9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_E9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_E9.Location = new System.Drawing.Point(704, 283);
            this.btn_ff_E9.Name = "btn_ff_E9";
            this.btn_ff_E9.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_E9.TabIndex = 40;
            this.btn_ff_E9.Text = "E9";
            this.btn_ff_E9.UseVisualStyleBackColor = false;
            this.btn_ff_E9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_E6
            // 
            this.btn_ff_E6.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_E6.FlatAppearance.BorderSize = 0;
            this.btn_ff_E6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_E6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_E6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_E6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_E6.Location = new System.Drawing.Point(437, 283);
            this.btn_ff_E6.Name = "btn_ff_E6";
            this.btn_ff_E6.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_E6.TabIndex = 39;
            this.btn_ff_E6.Text = "E6";
            this.btn_ff_E6.UseVisualStyleBackColor = false;
            this.btn_ff_E6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_E5
            // 
            this.btn_ff_E5.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_E5.FlatAppearance.BorderSize = 0;
            this.btn_ff_E5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_E5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_E5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_E5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_E5.Location = new System.Drawing.Point(371, 283);
            this.btn_ff_E5.Name = "btn_ff_E5";
            this.btn_ff_E5.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_E5.TabIndex = 38;
            this.btn_ff_E5.Text = "E5";
            this.btn_ff_E5.UseVisualStyleBackColor = false;
            this.btn_ff_E5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_F8
            // 
            this.btn_ff_F8.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_F8.FlatAppearance.BorderSize = 0;
            this.btn_ff_F8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_F8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_F8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_F8.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_F8.Location = new System.Drawing.Point(638, 217);
            this.btn_ff_F8.Name = "btn_ff_F8";
            this.btn_ff_F8.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_F8.TabIndex = 37;
            this.btn_ff_F8.Text = "F8";
            this.btn_ff_F8.UseVisualStyleBackColor = false;
            this.btn_ff_F8.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_F9
            // 
            this.btn_ff_F9.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_F9.FlatAppearance.BorderSize = 0;
            this.btn_ff_F9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_F9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_F9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_F9.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_F9.Location = new System.Drawing.Point(704, 217);
            this.btn_ff_F9.Name = "btn_ff_F9";
            this.btn_ff_F9.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_F9.TabIndex = 36;
            this.btn_ff_F9.Text = "F9";
            this.btn_ff_F9.UseVisualStyleBackColor = false;
            this.btn_ff_F9.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_F6
            // 
            this.btn_ff_F6.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_F6.FlatAppearance.BorderSize = 0;
            this.btn_ff_F6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_F6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_F6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_F6.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_F6.Location = new System.Drawing.Point(437, 217);
            this.btn_ff_F6.Name = "btn_ff_F6";
            this.btn_ff_F6.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_F6.TabIndex = 35;
            this.btn_ff_F6.Text = "F6";
            this.btn_ff_F6.UseVisualStyleBackColor = false;
            this.btn_ff_F6.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_F5
            // 
            this.btn_ff_F5.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_F5.FlatAppearance.BorderSize = 0;
            this.btn_ff_F5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_F5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_F5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_F5.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_F5.Location = new System.Drawing.Point(371, 217);
            this.btn_ff_F5.Name = "btn_ff_F5";
            this.btn_ff_F5.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_F5.TabIndex = 34;
            this.btn_ff_F5.Text = "F5";
            this.btn_ff_F5.UseVisualStyleBackColor = false;
            this.btn_ff_F5.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_A4
            // 
            this.btn_ff_A4.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_A4.FlatAppearance.BorderSize = 0;
            this.btn_ff_A4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_A4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_A4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_A4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_A4.Location = new System.Drawing.Point(305, 547);
            this.btn_ff_A4.Name = "btn_ff_A4";
            this.btn_ff_A4.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_A4.TabIndex = 33;
            this.btn_ff_A4.Text = "A4";
            this.btn_ff_A4.UseVisualStyleBackColor = false;
            this.btn_ff_A4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_A3
            // 
            this.btn_ff_A3.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_A3.FlatAppearance.BorderSize = 0;
            this.btn_ff_A3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_A3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_A3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_A3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_A3.Location = new System.Drawing.Point(245, 547);
            this.btn_ff_A3.Name = "btn_ff_A3";
            this.btn_ff_A3.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_A3.TabIndex = 32;
            this.btn_ff_A3.Text = "A3";
            this.btn_ff_A3.UseVisualStyleBackColor = false;
            this.btn_ff_A3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_A2
            // 
            this.btn_ff_A2.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_A2.FlatAppearance.BorderSize = 0;
            this.btn_ff_A2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_A2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_A2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_A2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_A2.Location = new System.Drawing.Point(119, 547);
            this.btn_ff_A2.Name = "btn_ff_A2";
            this.btn_ff_A2.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_A2.TabIndex = 31;
            this.btn_ff_A2.Text = "A2";
            this.btn_ff_A2.UseVisualStyleBackColor = false;
            this.btn_ff_A2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_A1
            // 
            this.btn_ff_A1.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_A1.FlatAppearance.BorderSize = 0;
            this.btn_ff_A1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_A1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_A1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_A1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_A1.Location = new System.Drawing.Point(53, 547);
            this.btn_ff_A1.Name = "btn_ff_A1";
            this.btn_ff_A1.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_A1.TabIndex = 30;
            this.btn_ff_A1.Text = "A1";
            this.btn_ff_A1.UseVisualStyleBackColor = false;
            this.btn_ff_A1.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_B4
            // 
            this.btn_ff_B4.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_B4.FlatAppearance.BorderSize = 0;
            this.btn_ff_B4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_B4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_B4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_B4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_B4.Location = new System.Drawing.Point(305, 481);
            this.btn_ff_B4.Name = "btn_ff_B4";
            this.btn_ff_B4.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_B4.TabIndex = 29;
            this.btn_ff_B4.Text = "B4";
            this.btn_ff_B4.UseVisualStyleBackColor = false;
            this.btn_ff_B4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_B3
            // 
            this.btn_ff_B3.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_B3.FlatAppearance.BorderSize = 0;
            this.btn_ff_B3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_B3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_B3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_B3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_B3.Location = new System.Drawing.Point(245, 481);
            this.btn_ff_B3.Name = "btn_ff_B3";
            this.btn_ff_B3.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_B3.TabIndex = 28;
            this.btn_ff_B3.Text = "B3";
            this.btn_ff_B3.UseVisualStyleBackColor = false;
            this.btn_ff_B3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_B2
            // 
            this.btn_ff_B2.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_B2.FlatAppearance.BorderSize = 0;
            this.btn_ff_B2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_B2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_B2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_B2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_B2.Location = new System.Drawing.Point(119, 481);
            this.btn_ff_B2.Name = "btn_ff_B2";
            this.btn_ff_B2.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_B2.TabIndex = 27;
            this.btn_ff_B2.Text = "B2";
            this.btn_ff_B2.UseVisualStyleBackColor = false;
            this.btn_ff_B2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_B1
            // 
            this.btn_ff_B1.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_B1.FlatAppearance.BorderSize = 0;
            this.btn_ff_B1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_B1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_B1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_B1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_B1.Location = new System.Drawing.Point(53, 481);
            this.btn_ff_B1.Name = "btn_ff_B1";
            this.btn_ff_B1.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_B1.TabIndex = 26;
            this.btn_ff_B1.Text = "B1";
            this.btn_ff_B1.UseVisualStyleBackColor = false;
            this.btn_ff_B1.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_C4
            // 
            this.btn_ff_C4.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_C4.FlatAppearance.BorderSize = 0;
            this.btn_ff_C4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_C4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_C4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_C4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_C4.Location = new System.Drawing.Point(305, 415);
            this.btn_ff_C4.Name = "btn_ff_C4";
            this.btn_ff_C4.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_C4.TabIndex = 25;
            this.btn_ff_C4.Text = "C4";
            this.btn_ff_C4.UseVisualStyleBackColor = false;
            this.btn_ff_C4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_C3
            // 
            this.btn_ff_C3.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_C3.FlatAppearance.BorderSize = 0;
            this.btn_ff_C3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_C3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_C3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_C3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_C3.Location = new System.Drawing.Point(245, 415);
            this.btn_ff_C3.Name = "btn_ff_C3";
            this.btn_ff_C3.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_C3.TabIndex = 24;
            this.btn_ff_C3.Text = "C3";
            this.btn_ff_C3.UseVisualStyleBackColor = false;
            this.btn_ff_C3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_C2
            // 
            this.btn_ff_C2.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_C2.FlatAppearance.BorderSize = 0;
            this.btn_ff_C2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_C2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_C2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_C2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_C2.Location = new System.Drawing.Point(119, 415);
            this.btn_ff_C2.Name = "btn_ff_C2";
            this.btn_ff_C2.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_C2.TabIndex = 23;
            this.btn_ff_C2.Text = "C2";
            this.btn_ff_C2.UseVisualStyleBackColor = false;
            this.btn_ff_C2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_C1
            // 
            this.btn_ff_C1.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_C1.FlatAppearance.BorderSize = 0;
            this.btn_ff_C1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_C1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_C1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_C1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_C1.Location = new System.Drawing.Point(53, 415);
            this.btn_ff_C1.Name = "btn_ff_C1";
            this.btn_ff_C1.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_C1.TabIndex = 22;
            this.btn_ff_C1.Text = "C1";
            this.btn_ff_C1.UseVisualStyleBackColor = false;
            this.btn_ff_C1.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_D4
            // 
            this.btn_ff_D4.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_D4.FlatAppearance.BorderSize = 0;
            this.btn_ff_D4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_D4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_D4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_D4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_D4.Location = new System.Drawing.Point(305, 349);
            this.btn_ff_D4.Name = "btn_ff_D4";
            this.btn_ff_D4.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_D4.TabIndex = 21;
            this.btn_ff_D4.Text = "D4";
            this.btn_ff_D4.UseVisualStyleBackColor = false;
            this.btn_ff_D4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_D3
            // 
            this.btn_ff_D3.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_D3.FlatAppearance.BorderSize = 0;
            this.btn_ff_D3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_D3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_D3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_D3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_D3.Location = new System.Drawing.Point(245, 349);
            this.btn_ff_D3.Name = "btn_ff_D3";
            this.btn_ff_D3.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_D3.TabIndex = 20;
            this.btn_ff_D3.Text = "D3";
            this.btn_ff_D3.UseVisualStyleBackColor = false;
            this.btn_ff_D3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_D2
            // 
            this.btn_ff_D2.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_D2.FlatAppearance.BorderSize = 0;
            this.btn_ff_D2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_D2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_D2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_D2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_D2.Location = new System.Drawing.Point(119, 349);
            this.btn_ff_D2.Name = "btn_ff_D2";
            this.btn_ff_D2.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_D2.TabIndex = 19;
            this.btn_ff_D2.Text = "D2";
            this.btn_ff_D2.UseVisualStyleBackColor = false;
            this.btn_ff_D2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_D1
            // 
            this.btn_ff_D1.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_D1.FlatAppearance.BorderSize = 0;
            this.btn_ff_D1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_D1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_D1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_D1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_D1.Location = new System.Drawing.Point(53, 349);
            this.btn_ff_D1.Name = "btn_ff_D1";
            this.btn_ff_D1.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_D1.TabIndex = 18;
            this.btn_ff_D1.Text = "D1";
            this.btn_ff_D1.UseVisualStyleBackColor = false;
            this.btn_ff_D1.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_E4
            // 
            this.btn_ff_E4.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_E4.FlatAppearance.BorderSize = 0;
            this.btn_ff_E4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_E4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_E4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_E4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_E4.Location = new System.Drawing.Point(305, 283);
            this.btn_ff_E4.Name = "btn_ff_E4";
            this.btn_ff_E4.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_E4.TabIndex = 17;
            this.btn_ff_E4.Text = "E4";
            this.btn_ff_E4.UseVisualStyleBackColor = false;
            this.btn_ff_E4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_E3
            // 
            this.btn_ff_E3.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_E3.FlatAppearance.BorderSize = 0;
            this.btn_ff_E3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_E3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_E3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_E3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_E3.Location = new System.Drawing.Point(245, 283);
            this.btn_ff_E3.Name = "btn_ff_E3";
            this.btn_ff_E3.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_E3.TabIndex = 16;
            this.btn_ff_E3.Text = "E3";
            this.btn_ff_E3.UseVisualStyleBackColor = false;
            this.btn_ff_E3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_E2
            // 
            this.btn_ff_E2.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_E2.FlatAppearance.BorderSize = 0;
            this.btn_ff_E2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_E2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_E2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_E2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_E2.Location = new System.Drawing.Point(119, 283);
            this.btn_ff_E2.Name = "btn_ff_E2";
            this.btn_ff_E2.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_E2.TabIndex = 15;
            this.btn_ff_E2.Text = "E2";
            this.btn_ff_E2.UseVisualStyleBackColor = false;
            this.btn_ff_E2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_E1
            // 
            this.btn_ff_E1.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_E1.FlatAppearance.BorderSize = 0;
            this.btn_ff_E1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_E1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_E1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_E1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_E1.Location = new System.Drawing.Point(53, 283);
            this.btn_ff_E1.Name = "btn_ff_E1";
            this.btn_ff_E1.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_E1.TabIndex = 14;
            this.btn_ff_E1.Text = "E1";
            this.btn_ff_E1.UseVisualStyleBackColor = false;
            this.btn_ff_E1.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_F4
            // 
            this.btn_ff_F4.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_F4.FlatAppearance.BorderSize = 0;
            this.btn_ff_F4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_F4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_F4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_F4.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_F4.Location = new System.Drawing.Point(305, 217);
            this.btn_ff_F4.Name = "btn_ff_F4";
            this.btn_ff_F4.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_F4.TabIndex = 13;
            this.btn_ff_F4.Text = "F4";
            this.btn_ff_F4.UseVisualStyleBackColor = false;
            this.btn_ff_F4.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_F3
            // 
            this.btn_ff_F3.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_F3.FlatAppearance.BorderSize = 0;
            this.btn_ff_F3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_F3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_F3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_F3.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_F3.Location = new System.Drawing.Point(245, 217);
            this.btn_ff_F3.Name = "btn_ff_F3";
            this.btn_ff_F3.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_F3.TabIndex = 12;
            this.btn_ff_F3.Text = "F3";
            this.btn_ff_F3.UseVisualStyleBackColor = false;
            this.btn_ff_F3.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_F2
            // 
            this.btn_ff_F2.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_F2.FlatAppearance.BorderSize = 0;
            this.btn_ff_F2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_F2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_F2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_F2.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_F2.Location = new System.Drawing.Point(119, 217);
            this.btn_ff_F2.Name = "btn_ff_F2";
            this.btn_ff_F2.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_F2.TabIndex = 11;
            this.btn_ff_F2.Text = "F2";
            this.btn_ff_F2.UseVisualStyleBackColor = false;
            this.btn_ff_F2.Click += new System.EventHandler(this.cekbangku);
            // 
            // btn_ff_F1
            // 
            this.btn_ff_F1.BackColor = System.Drawing.Color.Transparent;
            this.btn_ff_F1.FlatAppearance.BorderSize = 0;
            this.btn_ff_F1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ff_F1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ff_F1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_ff_F1.Image = global::Project_UTS_v1.Properties.Resources.bangku_off;
            this.btn_ff_F1.Location = new System.Drawing.Point(53, 217);
            this.btn_ff_F1.Name = "btn_ff_F1";
            this.btn_ff_F1.Size = new System.Drawing.Size(60, 60);
            this.btn_ff_F1.TabIndex = 10;
            this.btn_ff_F1.Text = "F1";
            this.btn_ff_F1.UseVisualStyleBackColor = false;
            this.btn_ff_F1.Click += new System.EventHandler(this.cekbangku);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(72)))), ((int)(((byte)(24)))));
            this.label12.Location = new System.Drawing.Point(225, 46);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(393, 46);
            this.label12.TabIndex = 9;
            this.label12.Text = "Fast and Farious 8";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(72)))), ((int)(((byte)(24)))));
            this.panel12.Location = new System.Drawing.Point(336, 95);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(150, 2);
            this.panel12.TabIndex = 8;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(41)))), ((int)(((byte)(5)))));
            this.panel13.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel13.Location = new System.Drawing.Point(365, 0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(5, 743);
            this.panel13.TabIndex = 1;
            // 
            // menu
            // 
            this.menu.BackgroundImage = global::Project_UTS_v1.Properties.Resources.Form_Login_Menu1;
            this.menu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menu.Controls.Add(this.panel13);
            this.menu.Controls.Add(this.panel4);
            this.menu.Controls.Add(this.panel1);
            this.menu.Controls.Add(this.btnbangku);
            this.menu.Controls.Add(this.btnfilm);
            this.menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(370, 743);
            this.menu.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(41)))), ((int)(((byte)(5)))));
            this.panel4.Location = new System.Drawing.Point(0, 329);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(10, 95);
            this.panel4.TabIndex = 2;
            this.panel4.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(41)))), ((int)(((byte)(5)))));
            this.panel1.Location = new System.Drawing.Point(0, 227);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(10, 95);
            this.panel1.TabIndex = 1;
            // 
            // btnbangku
            // 
            this.btnbangku.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(168)))), ((int)(((byte)(120)))));
            this.btnbangku.Enabled = false;
            this.btnbangku.FlatAppearance.BorderSize = 0;
            this.btnbangku.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbangku.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbangku.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(23)))), ((int)(((byte)(19)))));
            this.btnbangku.Image = global::Project_UTS_v1.Properties.Resources.seat;
            this.btnbangku.Location = new System.Drawing.Point(3, 328);
            this.btnbangku.Name = "btnbangku";
            this.btnbangku.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btnbangku.Size = new System.Drawing.Size(361, 96);
            this.btnbangku.TabIndex = 0;
            this.btnbangku.Text = "Bangku";
            this.btnbangku.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnbangku.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnbangku.UseVisualStyleBackColor = false;
            this.btnbangku.Click += new System.EventHandler(this.btnbangku_Click);
            // 
            // btnfilm
            // 
            this.btnfilm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(168)))), ((int)(((byte)(120)))));
            this.btnfilm.FlatAppearance.BorderSize = 0;
            this.btnfilm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnfilm.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfilm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(23)))), ((int)(((byte)(19)))));
            this.btnfilm.Image = ((System.Drawing.Image)(resources.GetObject("btnfilm.Image")));
            this.btnfilm.Location = new System.Drawing.Point(3, 226);
            this.btnfilm.Name = "btnfilm";
            this.btnfilm.Size = new System.Drawing.Size(361, 96);
            this.btnfilm.TabIndex = 0;
            this.btnfilm.Text = "Film";
            this.btnfilm.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnfilm.UseVisualStyleBackColor = false;
            this.btnfilm.Click += new System.EventHandler(this.btnfilm_Click);
            // 
            // kontentfilm
            // 
            this.kontentfilm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(168)))), ((int)(((byte)(120)))));
            this.kontentfilm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.kontentfilm.Controls.Add(this.groupBox2);
            this.kontentfilm.Controls.Add(this.panel3);
            this.kontentfilm.Controls.Add(this.label1);
            this.kontentfilm.Controls.Add(this.groupBox1);
            this.kontentfilm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kontentfilm.Location = new System.Drawing.Point(370, 38);
            this.kontentfilm.Name = "kontentfilm";
            this.kontentfilm.Size = new System.Drawing.Size(830, 705);
            this.kontentfilm.TabIndex = 4;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cb_jmlorang);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.tbPengunjung);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(70, 100);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(681, 72);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Data Pesanan";
            // 
            // cb_jmlorang
            // 
            this.cb_jmlorang.FormattingEnabled = true;
            this.cb_jmlorang.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cb_jmlorang.Location = new System.Drawing.Point(483, 36);
            this.cb_jmlorang.Name = "cb_jmlorang";
            this.cb_jmlorang.Size = new System.Drawing.Size(121, 24);
            this.cb_jmlorang.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(379, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 17);
            this.label5.TabIndex = 2;
            this.label5.Text = "Jumlah Kursi";
            // 
            // tbPengunjung
            // 
            this.tbPengunjung.Location = new System.Drawing.Point(71, 36);
            this.tbPengunjung.Name = "tbPengunjung";
            this.tbPengunjung.Size = new System.Drawing.Size(271, 22);
            this.tbPengunjung.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "Nama";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(72)))), ((int)(((byte)(24)))));
            this.panel3.Location = new System.Drawing.Point(368, 74);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(94, 2);
            this.panel3.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(72)))), ((int)(((byte)(24)))));
            this.label1.Location = new System.Drawing.Point(345, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 56);
            this.label1.TabIndex = 6;
            this.label1.Text = "FILM";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.btnFF);
            this.groupBox1.Controls.Add(this.btnBP);
            this.groupBox1.Controls.Add(this.btnEG);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(70, 189);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(681, 408);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(465, 24);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(200, 294);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // btnFF
            // 
            this.btnFF.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFF.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(72)))), ((int)(((byte)(24)))));
            this.btnFF.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(168)))), ((int)(((byte)(120)))));
            this.btnFF.FlatAppearance.BorderSize = 2;
            this.btnFF.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(41)))), ((int)(((byte)(5)))));
            this.btnFF.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(148)))), ((int)(((byte)(75)))));
            this.btnFF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFF.Font = new System.Drawing.Font("Cocogoose Pro", 7.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFF.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnFF.Location = new System.Drawing.Point(462, 332);
            this.btnFF.Name = "btnFF";
            this.btnFF.Size = new System.Drawing.Size(203, 61);
            this.btnFF.TabIndex = 5;
            this.btnFF.Text = "Fast and Furious 8";
            this.btnFF.UseVisualStyleBackColor = false;
            this.btnFF.Click += new System.EventHandler(this.getjudulfilm);
            // 
            // btnBP
            // 
            this.btnBP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(72)))), ((int)(((byte)(24)))));
            this.btnBP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(168)))), ((int)(((byte)(120)))));
            this.btnBP.FlatAppearance.BorderSize = 2;
            this.btnBP.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(41)))), ((int)(((byte)(5)))));
            this.btnBP.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(148)))), ((int)(((byte)(75)))));
            this.btnBP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBP.Font = new System.Drawing.Font("Cocogoose Pro", 7.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBP.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnBP.Location = new System.Drawing.Point(241, 332);
            this.btnBP.Name = "btnBP";
            this.btnBP.Size = new System.Drawing.Size(203, 61);
            this.btnBP.TabIndex = 4;
            this.btnBP.Text = "Black Pather";
            this.btnBP.UseVisualStyleBackColor = false;
            this.btnBP.Click += new System.EventHandler(this.getjudulfilm);
            // 
            // btnEG
            // 
            this.btnEG.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(72)))), ((int)(((byte)(24)))));
            this.btnEG.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(168)))), ((int)(((byte)(120)))));
            this.btnEG.FlatAppearance.BorderSize = 2;
            this.btnEG.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(41)))), ((int)(((byte)(5)))));
            this.btnEG.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(148)))), ((int)(((byte)(75)))));
            this.btnEG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEG.Font = new System.Drawing.Font("Cocogoose Pro", 7.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEG.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnEG.Location = new System.Drawing.Point(15, 332);
            this.btnEG.Name = "btnEG";
            this.btnEG.Size = new System.Drawing.Size(203, 61);
            this.btnEG.TabIndex = 0;
            this.btnEG.Text = "Avengers - End Game";
            this.btnEG.UseVisualStyleBackColor = false;
            this.btnEG.Click += new System.EventHandler(this.getjudulfilm);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(241, 24);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(200, 294);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(15, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 294);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(168)))), ((int)(((byte)(120)))));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1200, 743);
            this.panel2.TabIndex = 70;
            // 
            // Form_Film
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 743);
            this.Controls.Add(this.kontentfilm);
            this.Controls.Add(this.kontentbangku_bp);
            this.Controls.Add(this.kontentbangku_ff);
            this.Controls.Add(this.kontentbangku_eg);
            this.Controls.Add(this.toolbar);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form_Film";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form_Film";
            this.toolbar.ResumeLayout(false);
            this.kontentbangku_eg.ResumeLayout(false);
            this.kontentbangku_eg.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.kontentbangku_bp.ResumeLayout(false);
            this.kontentbangku_bp.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.kontentbangku_ff.ResumeLayout(false);
            this.kontentbangku_ff.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.menu.ResumeLayout(false);
            this.kontentfilm.ResumeLayout(false);
            this.kontentfilm.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel menu;
        private System.Windows.Forms.Panel toolbar;
        private System.Windows.Forms.Button btnminimiza;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.Panel kontentbangku_eg;
        private System.Windows.Forms.Button btnfilm;
        private System.Windows.Forms.Button btnbangku;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btn_eg_F1;
        private System.Windows.Forms.Button btn_eg_A9;
        private System.Windows.Forms.Button btn_eg_A6;
        private System.Windows.Forms.Button btn_eg_A5;
        private System.Windows.Forms.Button btn_eg_B8;
        private System.Windows.Forms.Button btn_eg_B9;
        private System.Windows.Forms.Button btn_eg_B6;
        private System.Windows.Forms.Button btn_eg_B5;
        private System.Windows.Forms.Button btn_eg_C8;
        private System.Windows.Forms.Button btn_eg_C9;
        private System.Windows.Forms.Button btn_eg_C6;
        private System.Windows.Forms.Button btn_eg_C5;
        private System.Windows.Forms.Button btn_eg_D8;
        private System.Windows.Forms.Button btn_eg_D9;
        private System.Windows.Forms.Button btn_eg_D6;
        private System.Windows.Forms.Button btn_eg_D5;
        private System.Windows.Forms.Button btn_eg_E8;
        private System.Windows.Forms.Button btn_eg_E9;
        private System.Windows.Forms.Button btn_eg_E6;
        private System.Windows.Forms.Button btn_eg_E5;
        private System.Windows.Forms.Button btn_eg_F8;
        private System.Windows.Forms.Button btn_eg_F9;
        private System.Windows.Forms.Button btn_eg_F6;
        private System.Windows.Forms.Button btn_eg_F5;
        private System.Windows.Forms.Button btn_eg_A4;
        private System.Windows.Forms.Button btn_eg_A3;
        private System.Windows.Forms.Button btn_eg_A2;
        private System.Windows.Forms.Button btn_eg_A1;
        private System.Windows.Forms.Button btn_eg_B4;
        private System.Windows.Forms.Button btn_eg_B3;
        private System.Windows.Forms.Button btn_eg_B2;
        private System.Windows.Forms.Button btn_eg_B1;
        private System.Windows.Forms.Button btn_eg_C4;
        private System.Windows.Forms.Button btn_eg_C3;
        private System.Windows.Forms.Button btn_eg_C2;
        private System.Windows.Forms.Button btn_eg_C1;
        private System.Windows.Forms.Button btn_eg_D4;
        private System.Windows.Forms.Button btn_eg_D3;
        private System.Windows.Forms.Button btn_eg_D2;
        private System.Windows.Forms.Button btn_eg_D1;
        private System.Windows.Forms.Button btn_eg_E4;
        private System.Windows.Forms.Button btn_eg_E3;
        private System.Windows.Forms.Button btn_eg_E2;
        private System.Windows.Forms.Button btn_eg_E1;
        private System.Windows.Forms.Button btn_eg_F4;
        private System.Windows.Forms.Button btn_eg_F3;
        private System.Windows.Forms.Button btn_eg_F2;
        private System.Windows.Forms.Button btn_eg_A7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_eg_A8;
        private System.Windows.Forms.Button btn_eg_B7;
        private System.Windows.Forms.Button btn_eg_C7;
        private System.Windows.Forms.Button btn_eg_D7;
        private System.Windows.Forms.Button btn_eg_E7;
        private System.Windows.Forms.Button btn_eg_F7;
        private System.Windows.Forms.Panel kontentbangku_bp;
        private System.Windows.Forms.Button btn_bp_A8;
        private System.Windows.Forms.Button btn_bp_B7;
        private System.Windows.Forms.Button btn_bp_C7;
        private System.Windows.Forms.Button btn_bp_D7;
        private System.Windows.Forms.Button btn_bp_E7;
        private System.Windows.Forms.Button btn_bp_F7;
        private System.Windows.Forms.Button btn_bp_A7;
        private System.Windows.Forms.Button btn_bp_A9;
        private System.Windows.Forms.Button btn_bp_A6;
        private System.Windows.Forms.Button btn_bp_A5;
        private System.Windows.Forms.Button btn_bp_B8;
        private System.Windows.Forms.Button btn_bp_B9;
        private System.Windows.Forms.Button btn_bp_B6;
        private System.Windows.Forms.Button btn_bp_B5;
        private System.Windows.Forms.Button btn_bp_C8;
        private System.Windows.Forms.Button btn_bp_C9;
        private System.Windows.Forms.Button btn_bp_C6;
        private System.Windows.Forms.Button btn_bp_C5;
        private System.Windows.Forms.Button btn_bp_D8;
        private System.Windows.Forms.Button btn_bp_D9;
        private System.Windows.Forms.Button btn_bp_D6;
        private System.Windows.Forms.Button btn_bp_D5;
        private System.Windows.Forms.Button btn_bp_E8;
        private System.Windows.Forms.Button btn_bp_E9;
        private System.Windows.Forms.Button btn_bp_E6;
        private System.Windows.Forms.Button btn_bp_E5;
        private System.Windows.Forms.Button btn_bp_F8;
        private System.Windows.Forms.Button btn_bp_F9;
        private System.Windows.Forms.Button btn_bp_F6;
        private System.Windows.Forms.Button btn_bp_F5;
        private System.Windows.Forms.Button btn_bp_A4;
        private System.Windows.Forms.Button btn_bp_A3;
        private System.Windows.Forms.Button btn_bp_A2;
        private System.Windows.Forms.Button btn_bp_A1;
        private System.Windows.Forms.Button btn_bp_B4;
        private System.Windows.Forms.Button btn_bp_B3;
        private System.Windows.Forms.Button btn_bp_B2;
        private System.Windows.Forms.Button btn_bp_B1;
        private System.Windows.Forms.Button btn_bp_C4;
        private System.Windows.Forms.Button btn_bp_C3;
        private System.Windows.Forms.Button btn_bp_C2;
        private System.Windows.Forms.Button btn_bp_C1;
        private System.Windows.Forms.Button btn_bp_D4;
        private System.Windows.Forms.Button btn_bp_D3;
        private System.Windows.Forms.Button btn_bp_D2;
        private System.Windows.Forms.Button btn_bp_D1;
        private System.Windows.Forms.Button btn_bp_E4;
        private System.Windows.Forms.Button btn_bp_E3;
        private System.Windows.Forms.Button btn_bp_E2;
        private System.Windows.Forms.Button btn_bp_E1;
        private System.Windows.Forms.Button btn_bp_F4;
        private System.Windows.Forms.Button btn_bp_F3;
        private System.Windows.Forms.Button btn_bp_F2;
        private System.Windows.Forms.Button btn_bp_F1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel kontentbangku_ff;
        private System.Windows.Forms.Button btn_ff_A8;
        private System.Windows.Forms.Button btn_ff_B7;
        private System.Windows.Forms.Button btn_ff_C7;
        private System.Windows.Forms.Button btn_ff_D7;
        private System.Windows.Forms.Button btn_ff_E7;
        private System.Windows.Forms.Button btn_ff_F7;
        private System.Windows.Forms.Button btn_ff_A7;
        private System.Windows.Forms.Button btn_ff_A9;
        private System.Windows.Forms.Button btn_ff_A6;
        private System.Windows.Forms.Button btn_ff_A5;
        private System.Windows.Forms.Button btn_ff_B8;
        private System.Windows.Forms.Button btn_ff_B9;
        private System.Windows.Forms.Button btn_ff_B6;
        private System.Windows.Forms.Button btn_ff_B5;
        private System.Windows.Forms.Button btn_ff_C8;
        private System.Windows.Forms.Button btn_ff_C9;
        private System.Windows.Forms.Button btn_ff_C6;
        private System.Windows.Forms.Button btn_ff_C5;
        private System.Windows.Forms.Button btn_ff_D8;
        private System.Windows.Forms.Button btn_ff_D9;
        private System.Windows.Forms.Button btn_ff_D6;
        private System.Windows.Forms.Button btn_ff_D5;
        private System.Windows.Forms.Button btn_ff_E8;
        private System.Windows.Forms.Button btn_ff_E9;
        private System.Windows.Forms.Button btn_ff_E6;
        private System.Windows.Forms.Button btn_ff_E5;
        private System.Windows.Forms.Button btn_ff_F8;
        private System.Windows.Forms.Button btn_ff_F9;
        private System.Windows.Forms.Button btn_ff_F6;
        private System.Windows.Forms.Button btn_ff_F5;
        private System.Windows.Forms.Button btn_ff_A3;
        private System.Windows.Forms.Button btn_ff_A2;
        private System.Windows.Forms.Button btn_ff_A1;
        private System.Windows.Forms.Button btn_ff_B3;
        private System.Windows.Forms.Button btn_ff_B2;
        private System.Windows.Forms.Button btn_ff_B1;
        private System.Windows.Forms.Button btn_ff_C3;
        private System.Windows.Forms.Button btn_ff_C2;
        private System.Windows.Forms.Button btn_ff_C1;
        private System.Windows.Forms.Button btn_ff_D3;
        private System.Windows.Forms.Button btn_ff_D2;
        private System.Windows.Forms.Button btn_ff_D1;
        private System.Windows.Forms.Button btn_ff_E3;
        private System.Windows.Forms.Button btn_ff_E2;
        private System.Windows.Forms.Button btn_ff_E1;
        private System.Windows.Forms.Button btn_ff_F3;
        private System.Windows.Forms.Button btn_ff_F2;
        private System.Windows.Forms.Button btn_ff_F1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Timer my_timer;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btn_ff_D4;
        private System.Windows.Forms.Button btn_ff_E4;
        private System.Windows.Forms.Button btn_ff_F4;
        private System.Windows.Forms.Button btn_ff_C4;
        private System.Windows.Forms.Button btn_ff_B4;
        private System.Windows.Forms.Button btn_ff_A4;
        private System.Windows.Forms.Panel kontentfilm;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cb_jmlorang;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbPengunjung;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnFF;
        private System.Windows.Forms.Button btnBP;
        private System.Windows.Forms.Button btnEG;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button1;
    }
}